import { useState } from 'react';
import { Download, Info } from 'lucide-react';
import { toast } from 'sonner';
import {
  DAILY_COST, DAILY_TOKENS, DEPT_USAGE, TOP_ASSETS, UNIT_DAU,
} from '@/data/mock';
import { AreaChart, HBarList, SectionHead } from '@/components/shared';
import { Button } from '@/components/ui/button';

const LABELS = Array.from({ length: 28 }, (_, i) => `9-${String(17 + i).padStart(2, '0')}`);

export default function UsageReport() {
  const [dim, setDim] = useState<'tokens' | 'cost'>('tokens');
  const series = dim === 'tokens' ? DAILY_TOKENS : DAILY_COST;
  const total = series.reduce((s, v) => s + v, 0);

  return (
    <div className="space-y-4">
      <SectionHead
        label="USAGE REPORT / J4"
        title="用量与成本穿透"
        extra="部门 / Agent / Skill 三维聚合 · 价格簿零价快照 + 内部采购成本参考 · 对外不呈现金额结算语义"
        actions={
          <Button variant="outline" size="sm" onClick={() => toast.success('已生成 CSV', { description: 'usage-report-2026-09.csv · 自助导出，下载行为记入审计' })}>
            <Download className="mr-1 size-3.5" /> 导出 CSV
          </Button>
        }
      />

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <div className="rounded-lg border bg-card p-4 xl:col-span-2">
          <div className="mb-3 flex items-center justify-between">
            <div className="flex items-center gap-1 rounded-md bg-muted/60 p-0.5">
              {([['tokens', '消耗（万 tokens）'], ['cost', '成本参考（元）']] as const).map(([v, label]) => (
                <button
                  key={v}
                  onClick={() => setDim(v)}
                  className={`rounded px-2.5 py-1 text-xs transition-colors ${dim === v ? 'bg-card font-medium shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}
                >
                  {label}
                </button>
              ))}
            </div>
            <span className="tnum mono text-xs text-muted-foreground">
              28 天合计 <span className="font-semibold text-foreground">{total.toLocaleString()}</span> {dim === 'tokens' ? '万 tokens' : '元'}
            </span>
          </div>
          <AreaChart series={series} labels={LABELS} height={200} unit={dim === 'tokens' ? '万 tokens / 日' : '元 / 日'} color={dim === 'cost' ? 'hsl(25 90% 40%)' : undefined} />
          <div className="mt-2 flex items-center gap-4 border-t pt-2.5 text-[11px] text-muted-foreground">
            <span className="inline-flex items-center gap-1"><Info className="size-3" /> 幂等键去重 · 死信 0 条 · 保留 730 天</span>
            <span className="ml-auto">事件保留策略：USAGE_RETENTION_DAYS=730</span>
          </div>
        </div>

        <div className="rounded-lg border bg-card p-4">
          <SectionHead label="BY ASSET / TOP" title="Top 资产消耗" extra="按内部成本参考排序 · 近 30 天" />
          <HBarList
            items={TOP_ASSETS.map((a) => ({ name: a.name, value: a.cost }))}
            format={(v) => `¥${v.toLocaleString()}`}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        {/* 部门明细 */}
        <div className="rounded-lg border bg-card p-4">
          <SectionHead label="BY ORG" title="部门用量分摊" extra="tokens 占比与环比 · 口径与审计一致" />
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b text-left text-[11px] text-muted-foreground">
                <th className="pb-2 font-medium">部门</th>
                <th className="pb-2 font-medium">消耗（万 tok）</th>
                <th className="w-32 pb-2 font-medium">占比</th>
                <th className="pb-2 text-right font-medium">环比</th>
              </tr>
            </thead>
            <tbody>
              {DEPT_USAGE.map((d) => (
                <tr key={d.org} className="border-b last:border-0">
                  <td className="py-2.5">{d.org}</td>
                  <td className="tnum mono py-2.5">{d.tokens.toLocaleString()}</td>
                  <td className="py-2.5">
                    <div className="flex items-center gap-2">
                      <div className="h-1.5 w-20 overflow-hidden rounded-full bg-stone-100">
                        <div className="h-full rounded-full bg-sky-700" style={{ width: `${d.share}%` }} />
                      </div>
                      <span className="tnum mono text-[11px] text-muted-foreground">{d.share}%</span>
                    </div>
                  </td>
                  <td className={`tnum mono py-2.5 text-right ${d.delta >= 0 ? 'text-emerald-700' : 'text-red-600'}`}>
                    {d.delta >= 0 ? '+' : ''}{d.delta}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* 单位 DAU 成本 */}
        <div className="rounded-lg border bg-card p-4">
          <SectionHead label="EFFICIENCY" title="应用效率：单位 DAU 成本" extra="指标 × 成本首次打通 · 窗口 DAU 派生" />
          <div className="space-y-3">
            {UNIT_DAU.map((u) => {
              const max = Math.max(...UNIT_DAU.map((x) => x.v));
              const high = u.v > 1;
              return (
                <div key={u.name}>
                  <div className="mb-1 flex items-baseline justify-between">
                    <span className="text-[13px]">{u.name}</span>
                    <span className={`tnum mono text-[12px] ${high ? 'text-amber-700' : 'text-foreground'}`}>
                      ¥{u.v.toFixed(2)} <span className="text-muted-foreground">/ DAU</span>
                    </span>
                  </div>
                  <div className="h-[5px] overflow-hidden rounded-full bg-stone-100">
                    <div className={`h-full rounded-full ${high ? 'bg-amber-500' : 'bg-emerald-600'}`} style={{ width: `${(u.v / max) * 100}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
          <p className="mt-3 border-t pt-3 text-[11px] leading-relaxed text-muted-foreground">
            排产调度 Agent 单位成本显著偏高（低频高消耗场景）——建议评估改用 qwen3-max 长文本路由或缓存编排模板。该洞察已同步经营分析驾驶舱。
          </p>
        </div>
      </div>
    </div>
  );
}
