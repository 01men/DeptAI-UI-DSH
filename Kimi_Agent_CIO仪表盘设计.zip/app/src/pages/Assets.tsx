import { useMemo, useState } from 'react';
import { Search, Zap, Plus, SlidersHorizontal } from 'lucide-react';
import { toast } from 'sonner';
import {
  ASSETS, ASSET_TYPE_LABEL,
} from '@/data/mock';
import type { Asset, AssetType } from '@/data/mock';
import { GrayProgress, HealthDot, LifecycleBadge, SectionHead, Sparkline, TypeBadge } from '@/components/shared';
import { Button } from '@/components/ui/button';
import AssetDrawer from '@/components/AssetDrawer';

const FILTERS: ('all' | AssetType)[] = ['all', 'mcp', 'agent', 'app', 'skill', 'model', 'nas'];

export default function Assets({ focusId }: { focusId?: string }) {
  const [filter, setFilter] = useState<'all' | AssetType>('all');
  const [q, setQ] = useState('');
  const [selected, setSelected] = useState<Asset | null>(
    focusId ? ASSETS.find((a) => a.id === focusId) ?? null : null,
  );

  const rows = useMemo(() => {
    return ASSETS.filter((a) => (filter === 'all' || a.type === filter))
      .filter((a) => !q || a.name.includes(q) || a.key.includes(q) || a.org.includes(q));
  }, [filter, q]);

  return (
    <div>
      <SectionHead
        label="ASSET LEDGER"
        title="资产台账"
        extra="MCP / Agent / 应用 / Skill / 模型路由 / NAS 六类资产一处盘点 · 统一归属、健康、用量与成本穿透"
        actions={
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => toast.success('健康巡检完成', { description: '20 项资产批量探活，1 项熔断（equipment-iot），结果已留痕' })}>
              <Zap className="mr-1 size-3.5" /> 一键巡检
            </Button>
            <Button size="sm" onClick={() => toast.info('渐进式创建', { description: '必填最小集先生成草稿，上线前强制补全治理属性' })}>
              <Plus className="mr-1 size-3.5" /> 登记资产
            </Button>
          </div>
        }
      />

      {/* 过滤条 */}
      <div className="mb-3 flex flex-wrap items-center gap-2">
        {FILTERS.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-full px-3 py-1 text-[12.5px] transition-colors ${
              filter === f ? 'bg-foreground text-background' : 'bg-card text-muted-foreground ring-1 ring-border hover:text-foreground'
            }`}
          >
            {f === 'all' ? '全部' : ASSET_TYPE_LABEL[f]}
            <span className="tnum mono ml-1.5 text-[10.5px] opacity-60">
              {f === 'all' ? ASSETS.length : ASSETS.filter((a) => a.type === f).length}
            </span>
          </button>
        ))}
        <div className="ml-auto flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="搜索名称 / 资源键 / 组织"
              className="h-8 w-56 rounded-md border bg-card pl-8 pr-3 text-[12.5px] outline-none ring-primary/30 placeholder:text-muted-foreground/70 focus:ring-2"
            />
          </div>
          <Button variant="outline" size="sm" className="h-8" onClick={() => toast.info('列设置', { description: '列显隐与排序为本地偏好，存储于浏览器' })}>
            <SlidersHorizontal className="mr-1 size-3.5" /> 列
          </Button>
        </div>
      </div>

      {/* 台账表 */}
      <div className="overflow-hidden rounded-lg border bg-card">
        <table className="w-full text-[13px]">
          <thead>
            <tr className="border-b bg-muted/40 text-left text-[11px] text-muted-foreground">
              <th className="px-4 py-2.5 font-medium">资产</th>
              <th className="px-3 py-2.5 font-medium">归属 / 负责人</th>
              <th className="px-3 py-2.5 font-medium">健康</th>
              <th className="px-3 py-2.5 text-right font-medium">30d 调用</th>
              <th className="px-3 py-2.5 text-right font-medium">30d 消耗</th>
              <th className="px-3 py-2.5 text-right font-medium">成本参考</th>
              <th className="px-3 py-2.5 font-medium">发布</th>
              <th className="px-4 py-2.5 text-right font-medium">趋势</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((a) => (
              <tr
                key={a.id}
                onClick={() => setSelected(a)}
                className="cursor-pointer border-b transition-colors last:border-0 hover:bg-muted/40"
              >
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2.5">
                    <TypeBadge type={a.type} />
                    <div className="min-w-0">
                      <div className="truncate font-medium">{a.name}</div>
                      <div className="tnum mono truncate text-[11px] text-muted-foreground">{a.key}</div>
                    </div>
                  </div>
                </td>
                <td className="px-3 py-3">
                  <div>{a.org}</div>
                  <div className="text-[11px] text-muted-foreground">{a.owner}</div>
                </td>
                <td className="px-3 py-3">
                  <HealthDot health={a.health} pulse={a.health === 'critical'} />
                  {a.grayPercent !== undefined && <div className="mt-1"><GrayProgress percent={a.grayPercent} /></div>}
                </td>
                <td className="tnum mono px-3 py-3 text-right">{a.calls30d.toLocaleString()}</td>
                <td className="tnum mono px-3 py-3 text-right">{a.tokens30d.toLocaleString()} 万</td>
                <td className="tnum mono px-3 py-3 text-right">¥{a.cost30d.toLocaleString()}</td>
                <td className="px-3 py-3"><LifecycleBadge s={a.lifecycle} /></td>
                <td className="px-4 py-3"><Sparkline data={a.trend} className="ml-auto block" /></td>
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length === 0 && (
          <div className="py-14 text-center text-[13px] text-muted-foreground">无匹配资产 — 试试调整筛选或搜索词</div>
        )}
      </div>
      <p className="mt-2 text-[11px] text-muted-foreground">
        点击行打开右侧详情抽屉（概览 / 监控 / 权限 / 拓扑 / 审计 / 生命周期）· 列表不跳页
      </p>

      <AssetDrawer asset={selected} open={!!selected} onClose={() => setSelected(null)} />
    </div>
  );
}
