import { useEffect, useMemo, useState } from 'react';
import {
  LayoutDashboard, Boxes, Store, Route as RouteIcon, BarChart3, FileCheck2, ShieldAlert,
  Building2, Plug, Search, Bell, Command, ChevronRight, CircleAlert, IceCreamCone,
} from 'lucide-react';
import { toast, Toaster } from 'sonner';
import {
  CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator,
} from '@/components/ui/command';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { ALERTS, APPROVALS, ASSETS, ASSET_TYPE_LABEL } from '@/data/mock';

import Dashboard from '@/pages/Dashboard';
import Assets from '@/pages/Assets';
import Market from '@/pages/Market';
import ModelGateway from '@/pages/ModelGateway';
import UsageReport from '@/pages/UsageReport';
import Approvals from '@/pages/Approvals';
import Audit from '@/pages/Audit';
import IAM from '@/pages/IAM';
import PlatformAccess from '@/pages/PlatformAccess';

export interface PageProps {
  go: (page: PageKey, assetId?: string) => void;
}

type PageKey = 'dashboard' | 'assets' | 'market' | 'gateway' | 'usage' | 'approvals' | 'audit' | 'iam' | 'access';

const NAV: { group: string; items: { key: PageKey; label: string; icon: any; badge?: number }[] }[] = [
  { group: '总览', items: [{ key: 'dashboard', label: '工作台', icon: LayoutDashboard }] },
  {
    group: '资源',
    items: [
      { key: 'assets', label: '资产台账', icon: Boxes },
      { key: 'market', label: 'AI 市场', icon: Store },
      { key: 'gateway', label: '模型网关', icon: RouteIcon },
    ],
  },
  {
    group: '治理',
    items: [
      { key: 'usage', label: '用量与成本', icon: BarChart3 },
      { key: 'approvals', label: '审批中心', icon: FileCheck2, badge: APPROVALS.length },
      { key: 'audit', label: '审计与告警', icon: ShieldAlert },
    ],
  },
  {
    group: '企业',
    items: [
      { key: 'iam', label: '组织与账号', icon: Building2 },
      { key: 'access', label: '平台接入', icon: Plug },
    ],
  },
];

const PAGE_TITLE: Record<PageKey, { title: string; sub: string }> = {
  dashboard: { title: '工作台', sub: '早上好，陈志远 · 今天是 2026-10-14 星期三' },
  assets: { title: '资产台账', sub: '统一盘点六类 AI 资产' },
  market: { title: 'AI 市场', sub: '团队级领域资产分发' },
  gateway: { title: '模型网关', sub: '分级路由与渠道治理' },
  usage: { title: '用量与成本', sub: '用量透明 · 内部成本穿透' },
  approvals: { title: '审批中心', sub: 'L4 护栏 · 危险操作可逆感知' },
  audit: { title: '审计与告警', sub: '四类日志 · 场景维度时间线' },
  iam: { title: '组织与账号', sub: '一套身份贯穿全部资源' },
  access: { title: '平台接入', sub: '连接器 · 凭证 · 远程客户端' },
};

export default function App() {
  const [page, setPage] = useState<PageKey>('dashboard');
  const [cmdk, setCmdk] = useState(false);
  const [assetFocus, setAssetFocus] = useState<string | undefined>(undefined);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setCmdk((v) => !v);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const go = (p: PageKey, assetId?: string) => {
    setPage(p);
    setAssetFocus(assetId);
    window.scrollTo({ top: 0 });
  };

  const paletteItems: { kind: string; label: string; key: PageKey; assetId?: string }[] = useMemo(
    () => [
      ...NAV.flatMap((g) => g.items).map((i) => ({ kind: '页面', label: i.label, key: i.key })),
      ...ASSETS.slice(0, 10).map((a) => ({ kind: ASSET_TYPE_LABEL[a.type], label: a.name, key: 'assets' as PageKey, assetId: a.id })),
    ],
    [],
  );

  return (
    <div className="min-h-screen">
      {/* ============ 侧栏 · 任务式导航 ============ */}
      <aside className="fixed inset-y-0 left-0 z-30 flex w-[218px] flex-col border-r bg-sidebar text-sidebar-foreground">
        <div className="flex h-14 items-center gap-2.5 border-b px-4">
          <span className="flex size-8 items-center justify-center rounded-lg bg-primary text-white shadow-sm">
            <IceCreamCone className="size-4" strokeWidth={2.2} />
          </span>
          <div className="leading-tight">
            <div className="text-[13.5px] font-semibold tracking-tight">元冰可 AIOS</div>
            <div className="text-[10px] text-muted-foreground">企业 AI 资源管理平台</div>
          </div>
        </div>

        <button
          onClick={() => setCmdk(true)}
          className="mx-3 mt-3 flex h-8 items-center gap-2 rounded-md border bg-card px-2.5 text-[12px] text-muted-foreground transition-colors hover:text-foreground"
        >
          <Search className="size-3.5" />
          搜索资源 / 跳页面 / 执行动作
          <kbd className="tnum mono ml-auto flex items-center gap-0.5 rounded border bg-muted px-1 py-px text-[10px]">
            <Command className="size-2.5" />K
          </kbd>
        </button>

        <nav className="flex-1 overflow-y-auto px-3 py-3">
          {NAV.map((g) => (
            <div key={g.group} className="mb-4 last:mb-0">
              <div className="micro-label mb-1.5 px-2">{g.group}</div>
              <div className="space-y-0.5">
                {g.items.map((item) => (
                  <button
                    key={item.key}
                    onClick={() => go(item.key)}
                    className={cn(
                      'flex w-full items-center gap-2.5 rounded-md px-2 py-[7px] text-[13px] transition-colors',
                      page === item.key
                        ? 'bg-sidebar-accent font-medium text-sidebar-accent-foreground shadow-[inset_2px_0_0_hsl(var(--sidebar-primary))]'
                        : 'text-sidebar-foreground/80 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground',
                    )}
                  >
                    <item.icon className="size-4 shrink-0 opacity-80" />
                    <span className="flex-1 text-left">{item.label}</span>
                    {item.badge ? (
                      <span className="tnum flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-primary px-1 text-[10.5px] font-semibold text-primary-foreground">
                        {item.badge}
                      </span>
                    ) : null}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </nav>

        {/* 环境 + 版本 */}
        <div className="border-t p-3 text-[11px] leading-relaxed text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <span className="flex items-center gap-1.5 rounded-full bg-emerald-600/10 px-2 py-0.5 font-medium text-emerald-700">
              <span className="size-[5px] rounded-full bg-emerald-600" /> 生产环境
            </span>
            <span className="mono ml-auto">v1.7.1</span>
          </div>
          <div className="mt-1.5 px-0.5">selftest 1201/1201 · 三端同构 REST/CLI/MCP</div>
        </div>
      </aside>

      {/* ============ 主区 ============ */}
      <div className="min-h-screen pl-[218px]">
        {/* 顶栏 */}
        <header className="sticky top-0 z-20 flex h-14 items-center gap-3 border-b bg-background/85 px-5 backdrop-blur">
          <div>
            <div className="text-[14px] font-semibold leading-tight">{PAGE_TITLE[page].title}</div>
            <div className="text-[10.5px] leading-tight text-muted-foreground">{PAGE_TITLE[page].sub}</div>
          </div>

          <div className="ml-auto flex items-center gap-2">
            {/* 平台自更新徽标 */}
            <button
              onClick={() => toast.info('发现新版本 v1.7.2', { description: 'git pull --ff-only + npm install · dry-run 已通过 · 是否升级由管理员决定' })}
              className="flex h-7 items-center gap-1.5 rounded-full border border-amber-300/70 bg-amber-50 px-2.5 text-[11px] font-medium text-amber-800 transition-colors hover:bg-amber-100"
            >
              <span className="size-[5px] rounded-full bg-amber-500 pulse-dot" style={{ ['--dot-color' as string]: '38 92% 50%' }} />
              可更新 v1.7.2
            </button>

            {/* 通知 */}
            <Popover>
              <PopoverTrigger asChild>
                <button className="relative flex size-8 items-center justify-center rounded-md border bg-card text-muted-foreground transition-colors hover:text-foreground">
                  <Bell className="size-4" />
                  <span className="absolute right-1.5 top-1.5 size-1.5 rounded-full bg-red-500" />
                </button>
              </PopoverTrigger>
              <PopoverContent align="end" className="w-[340px] p-0">
                <div className="border-b px-4 py-2.5 text-[13px] font-semibold">通知中心</div>
                <div className="max-h-[300px] overflow-y-auto">
                  {ALERTS.map((a, i) => (
                    <div key={i} className="flex items-start gap-2.5 border-b px-4 py-2.5 text-[12.5px] last:border-0">
                      <CircleAlert className={cn('mt-0.5 size-3.5 shrink-0', a.level === 'critical' ? 'text-red-600' : a.level === 'warning' ? 'text-amber-600' : 'text-sky-600')} />
                      <span className="leading-snug">{a.text}</span>
                    </div>
                  ))}
                </div>
              </PopoverContent>
            </Popover>

            {/* 用户 */}
            <Popover>
              <PopoverTrigger asChild>
                <button className="flex items-center gap-2.5 rounded-md py-1 pl-1 pr-2 transition-colors hover:bg-muted">
                  <Avatar className="size-8">
                    <AvatarFallback className="bg-primary text-[12px] font-semibold text-primary-foreground">陈</AvatarFallback>
                  </Avatar>
                  <span className="hidden text-left leading-tight md:block">
                    <span className="block text-[12.5px] font-medium">陈志远</span>
                    <span className="block text-[10.5px] text-muted-foreground">CIO · 平台超级管理员</span>
                  </span>
                  <ChevronRight className="size-3.5 rotate-90 text-muted-foreground" />
                </button>
              </PopoverTrigger>
              <PopoverContent align="end" className="w-56 p-1">
                {['个人设置', '我的审批', '切换组织', '退出登录'].map((m) => (
                  <button
                    key={m}
                    onClick={() => toast.info(m, { description: '演示原型 · 交互已留痕说明' })}
                    className="flex w-full rounded-md px-3 py-2 text-left text-[13px] transition-colors hover:bg-muted"
                  >
                    {m}
                  </button>
                ))}
              </PopoverContent>
            </Popover>
          </div>
        </header>

        {/* 告警滚动条 */}
        <div className="relative flex items-center overflow-hidden border-b bg-card">
          <div className="z-10 flex h-8 shrink-0 items-center gap-1.5 border-r bg-card px-3 text-[11px] font-semibold text-red-700">
            <CircleAlert className="size-3.5" /> 实时告警
          </div>
          <div className="relative flex-1 overflow-hidden">
            <div className="ticker-track flex w-max items-center whitespace-nowrap py-1 text-[12px] text-muted-foreground">
              {[...ALERTS, ...ALERTS].map((a, i) => (
                <span key={i} className="mx-6 flex items-center gap-2">
                  <span className={cn(
                    'size-[6px] rounded-full',
                    a.level === 'critical' ? 'bg-red-500' : a.level === 'warning' ? 'bg-amber-500' : 'bg-sky-500',
                  )} />
                  {a.text}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* 页面内容 */}
        <main className="mx-auto w-full max-w-[1400px] flex-1 px-5 py-5">
          <div key={page} className="fade-up">
            {page === 'dashboard' && <Dashboard go={go} />}
            {page === 'assets' && <Assets key={assetFocus ?? 'x'} focusId={assetFocus} />}
            {page === 'market' && <Market />}
            {page === 'gateway' && <ModelGateway />}
            {page === 'usage' && <UsageReport />}
            {page === 'approvals' && <Approvals />}
            {page === 'audit' && <Audit />}
            {page === 'iam' && <IAM />}
            {page === 'access' && <PlatformAccess />}
          </div>
        </main>

        <footer className="border-t px-5 py-3 text-center text-[10.5px] text-muted-foreground">
          元冰可 AIOS · 交互设计概念原型 — 数据为演示口径（DEMO_SEED），用量为透明计量与内部成本参考，不含任何金额结算语义
        </footer>
      </div>

      {/* ============ ⌘K 命令面板 ============ */}
      <CommandDialog open={cmdk} onOpenChange={setCmdk}>
        <CommandInput placeholder="搜索资源（Skill / Agent / 应用 / MCP）、跳页面、执行高频动作…" />
        <CommandList>
          <CommandEmpty>无匹配结果 — 试试「排产」「质检」「审批」</CommandEmpty>
          <CommandGroup heading="页面">
            {paletteItems.filter((i) => i.kind === '页面').map((i) => (
              <CommandItem
                key={i.label}
                onSelect={() => { setCmdk(false); go(i.key); }}
                className="gap-2"
              >
                <ChevronRight className="size-3.5 text-muted-foreground" />
                {i.label}
                <span className="ml-auto text-[10.5px] text-muted-foreground">跳转</span>
              </CommandItem>
            ))}
          </CommandGroup>
          <CommandSeparator />
          <CommandGroup heading="资源（点名直达）">
            {paletteItems.filter((i) => i.kind !== '页面').map((i) => (
              <CommandItem
                key={i.label}
                onSelect={() => { setCmdk(false); go('assets', i.assetId); }}
                className="gap-2"
              >
                <span className="rounded bg-muted px-1.5 py-0.5 text-[10px]">{i.kind}</span>
                {i.label}
                <span className="ml-auto text-[10.5px] text-muted-foreground">打开详情</span>
              </CommandItem>
            ))}
          </CommandGroup>
          <CommandSeparator />
          <CommandGroup heading="高频动作">
            {['导出月度用量 CSV', '创建 L4 审批单', '一键健康巡检', '轮换机器凭证'].map((a) => (
              <CommandItem key={a} onSelect={() => { setCmdk(false); toast.info(a, { description: '命令面板直达动作 · 真实环境将直接执行并留痕' }); }} className="gap-2">
                <Command className="size-3.5 text-muted-foreground" />
                {a}
              </CommandItem>
            ))}
          </CommandGroup>
        </CommandList>
      </CommandDialog>

      <Toaster position="top-center" richColors />
    </div>
  );
}
