// ============================================================
// 元冰可 AIOS · 制造业演示数据（华辰精密制造集团 · 虚构）
// 口径与平台契约对齐：usage schema v1 / 零价快照 + 内部成本参考
// ============================================================

export type AssetType = 'mcp' | 'agent' | 'app' | 'skill' | 'model' | 'nas';
export type Health = 'healthy' | 'warning' | 'critical' | 'offline';
export type Lifecycle = 'draft' | 'online' | 'offline' | 'archived' | 'deprecated';

export interface Asset {
  id: string;
  type: AssetType;
  name: string;
  key: string; // mono 资源键
  org: string;
  owner: string;
  health: Health;
  lifecycle: Lifecycle;
  grayPercent?: number; // 灰度发布进度
  calls30d: number;
  tokens30d: number; // 万 tokens
  cost30d: number; // 内部成本参考（元）
  dau?: number;
  desc: string;
  version?: string;
  autonomy?: 'A0' | 'A1' | 'A2' | 'A3';
  trend: number[]; // 近14天调用趋势
}

export const ASSET_TYPE_LABEL: Record<AssetType, string> = {
  mcp: 'MCP 服务',
  agent: 'Agent',
  app: 'AI 应用',
  skill: 'Skill',
  model: '模型路由',
  nas: 'NAS 存储',
};

export const HEALTH_LABEL: Record<Health, string> = {
  healthy: '健康',
  warning: '关注',
  critical: '熔断',
  offline: '离线',
};

export const LIFECYCLE_LABEL: Record<Lifecycle, string> = {
  draft: '草稿',
  online: '已上线',
  offline: '已下线',
  archived: '已归档',
  deprecated: '已弃用',
};

export const ORGS = [
  { id: 'org-zh', name: '智能工厂事业部', members: 486 },
  { id: 'org-zj', name: '质量检测中心', members: 132 },
  { id: 'org-gy', name: '供应链计划部', members: 87 },
  { id: 'org-sb', name: '设备运维部', members: 64 },
  { id: 'org-yf', name: '研发院', members: 213 },
  { id: 'org-cw', name: '财务经营部', members: 41 },
];

const t = (base: number, vol: number, seed: number) =>
  Array.from({ length: 14 }, (_, i) =>
    Math.max(0, Math.round(base + vol * Math.sin(i / 2.2 + seed) + ((i * seed * 7) % 13) - 6)),
  );

export const ASSETS: Asset[] = [
  {
    id: 'a1', type: 'mcp', name: '质检视觉推理服务', key: 'mcp:vision-quality',
    org: '质量检测中心', owner: '苏一鸣', health: 'healthy', lifecycle: 'online',
    calls30d: 48210, tokens30d: 3860, cost30d: 4218, version: 'v3.2.1',
    desc: '产线 AOI 图片缺陷判定推理网关，接入 3 条 SMT 产线 + 2 条机加产线的视觉质检工位。',
    trend: t(1800, 320, 3),
  },
  {
    id: 'a2', type: 'mcp', name: 'MES 数据网关', key: 'mcp:mes-gateway',
    org: '智能工厂事业部', owner: '苏一鸣', health: 'healthy', lifecycle: 'online',
    calls30d: 12044, tokens30d: 940, cost30d: 1062, version: 'v2.8.0',
    desc: '向 Agent 与应用暴露工单、报工、工序数据，只读约束 + Tool 粒度权限组。',
    trend: t(430, 90, 5),
  },
  {
    id: 'a3', type: 'mcp', name: '高级排产引擎', key: 'mcp:aps-engine',
    org: '供应链计划部', owner: '周启航', health: 'healthy', lifecycle: 'online', grayPercent: 40,
    calls30d: 3240, tokens30d: 5120, cost30d: 5870, version: 'v1.9.0 → v2.0.0',
    desc: 'TF 编排 + 步骤状态机，灰度 40%：插单重排场景由 v2.0.0 承接，支持一键回滚。',
    trend: t(120, 40, 7),
  },
  {
    id: 'a4', type: 'mcp', name: '设备物联网接入', key: 'mcp:equipment-iot',
    org: '设备运维部', owner: '周启航', health: 'critical', lifecycle: 'online',
    calls30d: 8902, tokens30d: 1180, cost30d: 1240, version: 'v1.4.2',
    desc: 'CNC / 注塑机台账与状态采集。连续 3 次探活失败已开熔断，业务成功即半闭合。',
    trend: t(360, 140, 9),
  },
  {
    id: 'a5', type: 'agent', name: '质量巡检助手', key: 'agent:quality-patrol',
    org: '质量检测中心', owner: '何静', health: 'healthy', lifecycle: 'online', autonomy: 'A1',
    calls30d: 9612, tokens30d: 2740, cost30d: 3012, dau: 214,
    desc: '绑定 128 名质检员，按点名直调（J1）触发巡检任务并回写实测 tokens。',
    trend: t(360, 60, 11),
  },
  {
    id: 'a6', type: 'agent', name: '排产调度 Agent', key: 'agent:aps-dispatch',
    org: '供应链计划部', owner: '周启航', health: 'healthy', lifecycle: 'online', autonomy: 'A2',
    calls30d: 5120, tokens30d: 4480, cost30d: 5210, dau: 38,
    desc: '自治级别 A2：可在审批模板内自主重排，超出模板自动转人工审批。',
    trend: t(190, 45, 13),
  },
  {
    id: 'a7', type: 'agent', name: '设备点检 Agent', key: 'agent:equipment-check',
    org: '设备运维部', owner: '苏一鸣', health: 'warning', lifecycle: 'online', autonomy: 'A1',
    calls30d: 4022, tokens30d: 980, cost30d: 1088, dau: 52,
    desc: '今日 09:14 起调用成功率 91.2%（SLO 98%），上游 equipment-iot 熔断传导。',
    trend: t(150, 55, 15),
  },
  {
    id: 'a8', type: 'agent', name: '供应商对账 Agent', key: 'agent:recon-vendor',
    org: '财务经营部', owner: '周启航', health: 'healthy', lifecycle: 'draft', autonomy: 'A0',
    calls30d: 0, tokens30d: 0, cost30d: 0, dau: 0,
    desc: '草稿态：治理属性已补全 7/9，差「数据出域评估」与「负责人确认」两项可提交上线。',
    trend: t(0, 0, 1),
  },
  {
    id: 'a9', type: 'app', name: 'SOP 智能问答', key: 'app:sop-qa',
    org: '智能工厂事业部', owner: '苏一鸣', health: 'healthy', lifecycle: 'online',
    calls30d: 30210, tokens30d: 5210, cost30d: 5840, dau: 1860,
    desc: 'H5 形态，钉钉工作台入口。上岗培训与工位 SOP 即问即答，7 日留存 46.8%。',
    trend: t(1120, 210, 17),
  },
  {
    id: 'a10', type: 'app', name: '质量追溯平台', key: 'app:qtrace',
    org: '质量检测中心', owner: '何静', health: 'healthy', lifecycle: 'online',
    calls30d: 8840, tokens30d: 1620, cost30d: 1780, dau: 764,
    desc: '批次 → 工序 → 检验记录 → 图片证据链反向追溯，血缘反向追溯已接通。',
    trend: t(320, 70, 19),
  },
  {
    id: 'a11', type: 'app', name: '经营分析驾驶舱', key: 'app:bi-cockpit',
    org: '财务经营部', owner: '陈志远', health: 'healthy', lifecycle: 'online',
    calls30d: 2140, tokens30d: 2280, cost30d: 2612, dau: 92,
    desc: '管理层周报自动生成，成本穿透报表按部门 / Agent / Skill 三维聚合。',
    trend: t(80, 18, 21),
  },
  {
    id: 'a12', type: 'skill', name: '缺陷判定 SOP 包', key: 'skill:defect-sop',
    org: '质量检测中心', owner: '苏一鸣', health: 'healthy', lifecycle: 'online', version: 'v1.4.0',
    calls30d: 15220, tokens30d: 890, cost30d: 40, desc: '封装 12 类常见缺陷判定标准与取样规则，已被 6 个 Agent 引用。',
    trend: t(560, 90, 23),
  },
  {
    id: 'a13', type: 'skill', name: '8D 报告生成', key: 'skill:8d-report',
    org: '研发院', owner: '苏一鸣', health: 'healthy', lifecycle: 'online', version: 'v2.1.3',
    calls30d: 640, tokens30d: 2100, cost30d: 96, desc: '客诉 8D 报告初稿生成，两级审批通过后上架，当前版本 Ed25519 验签通过。',
    trend: t(24, 8, 25),
  },
  {
    id: 'a14', type: 'skill', name: 'BOM 成本拆解', key: 'skill:bom-cost',
    org: '财务经营部', owner: '苏一鸣', health: 'healthy', lifecycle: 'draft', version: 'v0.9.0',
    calls30d: 0, tokens30d: 0, cost30d: 0, desc: '高风险技能：涉及成本数据出域，静态扫描通过，等待安全加签审批。',
    trend: t(0, 0, 2),
  },
  {
    id: 'a15', type: 'skill', name: '钉钉审批流', key: 'skill:dingtalk-flow',
    org: '智能工厂事业部', owner: '周启航', health: 'warning', lifecycle: 'deprecated', version: 'v0.3.1',
    calls30d: 12, tokens30d: 4, cost30d: 0, desc: '已被官方连接器替代，弃用原因：重复建设。3 个引用 Agent 已告警待迁移。',
    trend: t(1, 1, 27),
  },
  {
    id: 'a16', type: 'model', name: 'deepseek-v3.2 主路由', key: 'model:deepseek-v3.2',
    org: '研发院', owner: '陈志远', health: 'healthy', lifecycle: 'online',
    calls30d: 88120, tokens30d: 12400, cost30d: 13820,
    desc: '渠道组：主力（直连）→ 备用（代理）→ 兜底（量化版），按失败率自动降级。',
    trend: t(3200, 420, 29),
  },
  {
    id: 'a17', type: 'model', name: 'qwen3-max 路由', key: 'model:qwen3-max',
    org: '研发院', owner: '陈志远', health: 'healthy', lifecycle: 'online',
    calls30d: 12840, tokens30d: 3360, cost30d: 3920, desc: '长文本场景（8D 报告、合同评审）专用路由，预算熔断阈值 80%。',
    trend: t(460, 80, 31),
  },
  {
    id: 'a18', type: 'model', name: '视觉专用路由', key: 'model:vision-pro',
    org: '质量检测中心', owner: '陈志远', health: 'warning', lifecycle: 'online',
    calls30d: 22100, tokens30d: 6800, cost30d: 7640, desc: '主力渠道限流中，已自动降级至备用渠道，P95 延迟上升 180ms。',
    trend: t(820, 190, 33),
  },
  {
    id: 'a19', type: 'nas', name: '质检图片库', key: 'nas:quality-img',
    org: '质量检测中心', owner: '周启航', health: 'healthy', lifecycle: 'online',
    calls30d: 5210, tokens30d: 0, cost30d: 210, desc: '18.2 TB 质检图片证据，文件操作经 MCP 文件网关，RBAC 到班组。',
    trend: t(190, 40, 35),
  },
  {
    id: 'a20', type: 'nas', name: '工艺文件库', key: 'nas:process-doc',
    org: '研发院', owner: '周启航', health: 'healthy', lifecycle: 'online',
    calls30d: 1820, tokens30d: 0, cost30d: 60, desc: '6.4 TB 工艺文件，Skill 包 NAS 存储后端指向本资产 /skillhub 目录。',
    trend: t(66, 14, 37),
  },
];

// ---------- 用量与成本（J4 报表口径） ----------
export const USAGE_DAYS = 28;
export function genSeries(seed: number, base: number, growth: number, vol: number): number[] {
  return Array.from({ length: USAGE_DAYS }, (_, i) => {
    const wk = i % 7 === 5 || i % 7 === 6 ? 0.42 : 1; // 周末低谷
    const v = (base + growth * i) * wk + vol * Math.sin(i * 1.7 + seed) + ((i * seed * 11) % 17);
    return Math.max(8, Math.round(v));
  });
}
export const DAILY_TOKENS = genSeries(3, 720, 16, 90); // 万 tokens / 日
export const DAILY_CALLS = genSeries(7, 4200, 55, 480);
export const DAILY_COST = DAILY_TOKENS.map((v) => Math.round(v * 1.12 * 10) / 10);

export const DEPT_USAGE = [
  { org: '智能工厂事业部', tokens: 3240, share: 26.1, delta: +8.2 },
  { org: '质量检测中心', tokens: 2980, share: 24.0, delta: +12.6 },
  { org: '研发院', tokens: 2410, share: 19.4, delta: +3.1 },
  { org: '供应链计划部', tokens: 1980, share: 15.9, delta: +21.4 },
  { org: '设备运维部', tokens: 1090, share: 8.8, delta: -2.4 },
  { org: '财务经营部', tokens: 720, share: 5.8, delta: +1.2 },
];

export const TOP_ASSETS = ASSETS.filter((a) => a.cost30d > 0)
  .sort((x, y) => y.cost30d - x.cost30d)
  .slice(0, 8)
  .map((a) => ({ name: a.name, type: a.type, cost: a.cost30d, tokens: a.tokens30d, dau: a.dau }));

export const UNIT_DAU = [
  { name: 'SOP 智能问答', v: 0.10 },
  { name: '质量追溯平台', v: 0.08 },
  { name: '经营分析驾驶舱', v: 0.95 },
  { name: '排产调度 Agent', v: 4.57 },
  { name: '质量巡检助手', v: 0.47 },
];

// ---------- 审批中心（L4） ----------
export interface Approval {
  id: string;
  title: string;
  category: 'agent.online' | 'mcp.rollback' | 'skill.publish' | 'nas.exception' | 'app.online';
  applicant: string;
  org: string;
  submittedAt: string;
  risk: '常规' | '高风险' | '安全加签';
  reason: string;
  impact: string[];
  timeline: { time: string; actor: string; action: string; done: boolean }[];
}

export const APPROVALS: Approval[] = [
  {
    id: 'ap-1042', title: '供应商对账 Agent 上线', category: 'agent.online',
    applicant: '周启航', org: '财务经营部', submittedAt: '10-14 09:12', risk: '高风险',
    reason: '月末对账自动化试点，涉及应付账款数据读取。',
    impact: ['新增机器凭证 principal：agent-recon-vendor', '默认 scopes：mcp.invoke / skill.read / usage.write', '上线后将对 47 家供应商发起只读对账'],
    timeline: [
      { time: '10-14 09:12', actor: '周启航', action: '提交上线申请（治理属性 7/9）', done: true },
      { time: '10-14 09:31', actor: '系统', action: '完整性校验通过，转 L4 审批', done: true },
      { time: '—', actor: '陈志远', action: '待审批', done: false },
      { time: '—', actor: '系统', action: '执行上线 + 凭证签发', done: false },
    ],
  },
  {
    id: 'ap-1041', title: 'BOM 成本拆解 Skill 上架（v0.9.0）', category: 'skill.publish',
    applicant: '苏一鸣', org: '财务经营部', submittedAt: '10-13 17:48', risk: '安全加签',
    reason: '静态扫描通过；命中「成本数据出域」规则，需安全评审加签。',
    impact: ['包存储：NAS 工艺文件库 /skillhub', 'L1 门禁：恶意代码 0 命中 / 密钥泄露 0 命中', '上架后全员可见，计量键 calls'],
    timeline: [
      { time: '10-13 17:48', actor: '苏一鸣', action: '提交上架', done: true },
      { time: '10-13 18:02', actor: '系统', action: '静态扫描通过，标记安全加签', done: true },
      { time: '10-14 08:40', actor: '赵岚', action: '安全评审通过', done: true },
      { time: '—', actor: '陈志远', action: '待最终审批', done: false },
    ],
  },
  {
    id: 'ap-1040', title: '高级排产引擎回滚 v2.0.0 → v1.9.0', category: 'mcp.rollback',
    applicant: '周启航', org: '供应链计划部', submittedAt: '10-14 07:56', risk: '常规',
    reason: '灰度 40% 期间插单重排耗时 P95 超 SLO 2.3 倍，dry-run 影响面已通过。',
    impact: ['影响范围：灰度流量 40%（约 52 次调用/日）', '回滚耗时预计 8s，版本不可变', 'dry-run 结果：0 冲突，0 调用失败'],
    timeline: [
      { time: '10-14 07:56', actor: '周启航', action: '提交回滚（含 dry-run 报告）', done: true },
      { time: '10-14 08:10', actor: '系统', action: '回滚目标版本校验通过', done: true },
      { time: '—', actor: '陈志远', action: '待审批', done: false },
    ],
  },
  {
    id: 'ap-1039', title: '质检图片库班组共享例外（7 天）', category: 'nas.exception',
    applicant: '何静', org: '质量检测中心', submittedAt: '10-13 15:22', risk: '常规',
    reason: '一厂冲压班组跨班组调取 10 月客诉图片，走 share 审批例外。',
    impact: ['例外范围：/质检图片库/2026-10/客诉 只读', '有效期 7 天，到期自动拒绝', '破窗 override=false，全程留痕'],
    timeline: [
      { time: '10-13 15:22', actor: '何静', action: '提交例外申请', done: true },
      { time: '10-13 15:30', actor: '系统', action: '审批人沿组织链路由：冲压班组长', done: true },
      { time: '10-13 16:05', actor: '王铁军', action: '班组长通过', done: true },
      { time: '—', actor: '陈志远', action: '待归档确认', done: false },
    ],
  },
];

// ---------- 审计与告警 ----------
export interface AuditLog {
  id: string;
  time: string;
  type: 'auth' | 'invoke' | 'change' | 'security';
  actor: string;
  actChain: string[];
  action: string;
  target: string;
  result: 'ok' | 'deny' | 'alert';
}

export const AUDIT_LOGS: AuditLog[] = [
  { id: 'au-98231', time: '10-14 10:32:18', type: 'invoke', actor: '质量巡检助手', actChain: ['陈志远（用户）', 'agent:quality-patrol（Agent）', 'mcp:vision-quality'], action: 'tools/call 缺陷判定', target: 'mcp:vision-quality', result: 'ok' },
  { id: 'au-98230', time: '10-14 10:31:54', type: 'security', actor: '未知主体', actChain: ['外部 IP 113.108.*.*'], action: '登录失败锁定（5 次/15 分钟）', target: 'iam.login', result: 'alert' },
  { id: 'au-98229', time: '10-14 10:28:03', type: 'change', actor: '周启航', actChain: ['周启航'], action: 'mcp.gray.set 40%（v2.0.0 灰度）', target: 'mcp:aps-engine', result: 'ok' },
  { id: 'au-98228', time: '10-14 10:19:47', type: 'invoke', actor: '排产调度 Agent', actChain: ['周启航（用户）', 'agent:aps-dispatch', 'mcp:aps-engine'], action: 'TF 编排 插单重排 #2214', target: 'mcp:aps-engine', result: 'ok' },
  { id: 'au-98227', time: '10-14 10:02:11', type: 'auth', actor: '钉钉连接器', actChain: ['auto-sync'], action: '组织全量同步 1,023 人 / 42 部门', target: 'iam.connector.dingtalk', result: 'ok' },
  { id: 'au-98226', time: '10-14 09:58:40', type: 'security', actor: '机器凭证', actChain: ['agent:equipment-check'], action: 'usage.record 计量键不符，期望 output_tokens', target: 'usage.record', result: 'deny' },
  { id: 'au-98225', time: '10-14 09:44:02', type: 'invoke', actor: 'SOP 智能问答', actChain: ['访客 vid:8f3a', 'app:sop-qa', 'model:deepseek-v3.2'], action: '会话直通（J3）', target: 'model:deepseek-v3.2', result: 'ok' },
  { id: 'au-98224', time: '10-14 09:30:15', type: 'change', actor: '苏一鸣', actChain: ['苏一鸣'], action: 'credential.rotate 轮换 clientSecret', target: 'agent:quality-patrol', result: 'ok' },
  { id: 'au-98223', time: '10-14 09:12:00', type: 'auth', actor: '陈志远', actChain: ['陈志远'], action: 'SSO 授权 consent（经营分析驾驶舱）', target: 'app:bi-cockpit', result: 'ok' },
  { id: 'au-98222', time: '10-14 08:55:33', type: 'invoke', actor: 'open-connector', actChain: ['agent:recon-vendor（草稿）'], action: 'connector_execute 被拒绝：连接未授权', target: 'connector:erp-sap', result: 'deny' },
];

export const ALERTS = [
  { level: 'critical' as const, text: 'mcp:equipment-iot 连续 3 次探活失败，熔断已打开' },
  { level: 'warning' as const, text: 'skill:dingtalk-flow 已弃用，3 个引用 Agent 待迁移' },
  { level: 'warning' as const, text: 'model:vision-pro 主力渠道限流，已降级备用渠道（P95 +180ms）' },
  { level: 'info' as const, text: '连接器对账正常：28 天 run/meter 交叉校验 0 不符' },
  { level: 'info' as const, text: '钉钉组织定时同步完成：1,023 人 / 42 部门，0 冲突' },
];

// ---------- AI 市场 ----------
export interface MarketItem {
  id: string; name: string; publisher: string; category: string;
  installs: number; version: string; status: '已上架' | '审批中' | '已弃用';
  verified: boolean; risk: '低风险' | '中风险' | '高风险';
  heat: number[]; // 30 天使用热力
  desc: string;
}

const heat = (seed: number, base: number) =>
  Array.from({ length: 30 }, (_, i) => {
    const wk = i % 7 >= 5 ? 0.5 : 1;
    return Math.max(0, Math.round(base * wk + 12 * Math.sin(i + seed) + ((i * seed) % 9)));
  });

export const MARKET_ITEMS: MarketItem[] = [
  { id: 'm1', name: '缺陷判定 SOP 包', publisher: '质量检测中心 · 苏一鸣', category: '质量', installs: 312, version: 'v1.4.0', status: '已上架', verified: true, risk: '低风险', heat: heat(3, 42), desc: '12 类常见缺陷判定标准、取样规则与边界样例。' },
  { id: 'm2', name: '8D 报告生成', publisher: '研发院 · 苏一鸣', category: '质量', installs: 86, version: 'v2.1.3', status: '已上架', verified: true, risk: '中风险', heat: heat(5, 12), desc: '客诉 8D 报告初稿：问题描述 / 围堵 / 根因 / 纠正四段式。' },
  { id: 'm3', name: '设备点检知识库', publisher: '设备运维部 · 周启航', category: '设备', installs: 154, version: 'v1.1.0', status: '已上架', verified: true, risk: '低风险', heat: heat(7, 26), desc: '62 类设备点检标准与故障先兆特征库。' },
  { id: 'm4', name: 'BOM 成本拆解', publisher: '财务经营部 · 苏一鸣', category: '经营', installs: 0, version: 'v0.9.0', status: '审批中', verified: false, risk: '高风险', heat: heat(1, 0), desc: '成本数据出域场景，等待安全加签审批。' },
  { id: 'm5', name: '供应商交付风险画像', publisher: '供应链计划部 · 何静', category: '供应链', installs: 47, version: 'v0.8.2', status: '已上架', verified: true, risk: '中风险', heat: heat(11, 8), desc: '交付准时率 / 质量批次不良 / 响应时效三维画像。' },
  { id: 'm6', name: '钉钉审批流', publisher: '智能工厂事业部 · 周启航', category: '协同', installs: 203, version: 'v0.3.1', status: '已弃用', verified: true, risk: '低风险', heat: heat(13, 2), desc: '已被官方连接器替代，2026-11-30 后不再维护。' },
  { id: 'm7', name: '机加工工艺问答', publisher: '研发院 · 苏一鸣', category: '工艺', installs: 178, version: 'v1.0.6', status: '已上架', verified: true, risk: '低风险', heat: heat(17, 22), desc: '车 / 铣 / 磨 / 热处理工艺参数速查与选型建议。' },
  { id: 'm8', name: '安全作业规程助手', publisher: '智能工厂事业部 · 何静', category: '安全', installs: 265, version: 'v2.3.0', status: '已上架', verified: true, risk: '低风险', heat: heat(19, 34), desc: '特种作业规程、动火 / 受限空间作业审批要点。' },
];

// ---------- 模型网关 ----------
export interface ModelRoute {
  id: string; name: string; model: string; status: 'healthy' | 'warning';
  budget: number; used: number; // 预算熔断
  channels: { name: string; kind: '主力' | '备用' | '兜底'; state: 'active' | 'degraded' | 'standby'; p95: number }[];
  tokens30d: number; share: number;
}

export const MODEL_ROUTES: ModelRoute[] = [
  {
    id: 'r1', name: '通用对话主路由', model: 'deepseek-v3.2', status: 'healthy', budget: 80, used: 62,
    channels: [
      { name: '主力 · 直连专线', kind: '主力', state: 'active', p95: 840 },
      { name: '备用 · 代理网关', kind: '备用', state: 'standby', p95: 1210 },
      { name: '兜底 · 量化版', kind: '兜底', state: 'standby', p95: 1560 },
    ],
    tokens30d: 12400, share: 58,
  },
  {
    id: 'r2', name: '长文本路由', model: 'qwen3-max', status: 'healthy', budget: 80, used: 41,
    channels: [
      { name: '主力 · 直连专线', kind: '主力', state: 'active', p95: 1680 },
      { name: '兜底 · 代理网关', kind: '兜底', state: 'standby', p95: 2400 },
    ],
    tokens30d: 3360, share: 16,
  },
  {
    id: 'r3', name: '视觉理解路由', model: 'vision-pro', status: 'warning', budget: 80, used: 73,
    channels: [
      { name: '主力 · 直连专线', kind: '主力', state: 'degraded', p95: 2380 },
      { name: '备用 · 华东节点', kind: '备用', state: 'active', p95: 2560 },
    ],
    tokens30d: 6800, share: 26,
  },
];

// ---------- 组织 / 平台接入 ----------
export const IAM_USERS = [
  { name: '陈志远', account: 'admin', role: '平台超级管理员', org: '集团 / 信息化委员会', status: '在职', mfa: true },
  { name: '周启航', account: 'ops', role: '资源管理员', org: '集团 / 信息化部', status: '在职', mfa: true },
  { name: '何静', account: 'hr', role: '组织管理员', org: '集团 / 人力资源部', status: '在职', mfa: false },
  { name: '苏一鸣', account: 'dev', role: '开发者', org: '集团 / 信息化部', status: '在职', mfa: true },
  { name: '赵岚', account: 'audit', role: '审计员（只读）', org: '集团 / 审计部', status: '在职', mfa: true },
  { name: '林小满', account: 'DD0002', role: '班组长', org: '智能工厂事业部 / 一厂 / 冲压车间', status: '在职', mfa: false },
];

export const PLATFORM_CONN = {
  connector: { name: '钉钉连接器', mode: '真实 OpenAPI', intervalMinutes: 30, lastSync: '12 分钟前', members: 1023, conflicts: 0 },
  oidcClients: 12, machinePrincipals: 18, remoteDsh: 3,
};

// ============================================================
// 经营与执行（融合榕器 CIO 工作台 · 演示口径）
// ============================================================

export const FACTORIES = ['集团全部工厂', '金华工厂', '杭州工厂', '苏州工厂', '宁波工厂'];

export const INSIGHT = {
  text: '采购降本与质量改善贡献了 56% 的核验价值。生产排程存在数据约束，建议优先处理写入权限申请。',
  exceptions: [
    { name: '质量知识库同步中断', chain: '1 个依赖资源 → 1 项行动', owner: '张经理', level: 'warning' as const },
    { name: '设备物联网连接连续探活失败', chain: '1 个依赖资源 → 1 项行动', owner: '赵工', level: 'critical' as const },
  ],
};

export const BIZ_KPIS = [
  { label: 'AI 已核验业务价值', value: '¥ 126.8', unit: '万元', delta: '↑ 18.6%', deltaLabel: '较上期', kind: 'money' as const },
  { label: '关键行动达成率', value: '78.4', unit: '%', delta: '↑ 6.2pp', deltaLabel: '较上期', kind: 'rate' as const },
  { label: '数字员工任务完成率', value: '94.2', unit: '%', delta: '↑ 2.1pp', deltaLabel: '较上期', kind: 'rate' as const },
  { label: 'AI 预算使用率', value: '61.3', unit: '%', delta: '剩余 38.7%', deltaLabel: '当前预算', kind: 'budget' as const, used: 61.3 },
];

export const DECISIONS = [
  { title: '排程助手申请写入 MES 工单', org: '生产运营部', type: '权限变更', time: '14:30', icon: 'arrow' as const },
  { title: '采购助手灰度上线', org: '供应链中心', type: '上线审批', time: '15:00', icon: 'check' as const },
];

export interface Goal {
  tag: string; tagLabel: string; title: string; scope: string;
  value: string; unit: string; target: string; progress: number;
  owner: string; links: { name: string; pct: number }[];
}
export const GOALS: Goal[] = [
  {
    tag: '降本', tagLabel: '采购与运营', title: '可核验年度降本', scope: '经营目标 / 2026',
    value: '126.8', unit: '万元', target: '年度目标 200 万元 · 当前达成 63.4%', progress: 63.4,
    owner: '财务中心 · 业务部门',
    links: [{ name: '采购报价智能比对', pct: 86 }, { name: '设备预测性维护', pct: 43 }],
  },
  {
    tag: '提质', tagLabel: '质量与合规', title: '一次交检合格率', scope: '经营目标 / 2026',
    value: '98.1', unit: '%', target: '基线 96.8% → 目标 98.5%', progress: 84,
    owner: '质量管理部 · 张经理',
    links: [{ name: '质量异常闭环', pct: 72 }],
  },
  {
    tag: '增效', tagLabel: '交付与产能', title: '订单准交率', scope: '经营目标 / 2026',
    value: '94.6', unit: '%', target: '基线 91.2% → 目标 96%', progress: 78,
    owner: '生产运营部 · 李经理',
    links: [{ name: '生产排程优化', pct: 58 }],
  },
];

export const VERIFY_RULES = [
  { no: '01', title: '统一基线', desc: '使用可比业务口径，绑定数据来源、统计周期和排除项。集团价值汇总按唯一核验记录去重。' },
  { no: '02', title: '业务与财务核验', desc: '业务负责人确认改善结果，财务确认可归集价值。预计收益和已核验收益分开展示。' },
  { no: '03', title: '证据贯穿交付', desc: '每个结果附原始数据快照、分析过程和验收记录，可以从指标下钻到数字员工的执行链。' },
];

export const VALUE_ACTUAL = [6, 14, 22, 31, 40, 48, 55, 72, 80, 88, 96, 105, 115, 126.8];
export const VALUE_TARGET = [8, 18, 28, 38, 46, 56, 66, 76, 86, 96, 106, 116, 126, 136];
export const VALUE_LABELS = Array.from({ length: 14 }, (_, i) => `10/${String(i + 1).padStart(2, '0')}`);

export interface ActionProject {
  icon: string; name: string; goal: string; owner: string; org: string;
  progress: number; value?: string; status: '进行中' | '需关注' | '待验收';
}
export const ACTION_PROJECTS: ActionProject[] = [
  { icon: '质', name: '质量异常闭环', goal: '一次交检合格率提升至 98.5%', owner: '张经理', org: '质量管理部', progress: 72, value: '¥ 28.6 万', status: '进行中' },
  { icon: '产', name: '生产排程优化', goal: '订单准交率达到 96%', owner: '李经理', org: '生产运营部', progress: 58, status: '需关注' },
  { icon: '采', name: '采购报价智能比对', goal: '重点物料采购成本下降 5%', owner: '王经理', org: '供应链中心', progress: 86, value: '¥ 42.1 万', status: '待验收' },
  { icon: '设', name: '设备预测性维护', goal: '非计划停机时长下降 20%', owner: '赵工', org: '设备工程部', progress: 43, value: '¥ 15.8 万', status: '进行中' },
];

export interface KanbanTask { title: string; project: string; tag: '降本' | '提质' | '增效'; worker: string; due: string }
export const TASK_KANBAN: { col: string; tasks: KanbanTask[] }[] = [
  { col: '待办', tasks: [{ title: '分析本周交期偏差根因', project: '生产排程优化', tag: '增效', worker: '排程助手', due: '10 月 15 日' }] },
  {
    col: '进行中', tasks: [
      { title: '生成 A 线排程优化建议', project: '生产排程优化', tag: '增效', worker: '排程助手', due: '今天 17:00' },
      { title: '核验 3 号设备振动异常', project: '设备预测性维护', tag: '增效', worker: '设备诊断员', due: '10 月 15 日' },
    ],
  },
  {
    col: '待确认', tasks: [
      { title: '复核批次 Q-1024 纠正措施', project: '质量异常闭环', tag: '提质', worker: '质量分析员', due: '今天 16:30' },
      { title: '验收采购价格比对报告', project: '采购报价智能比对', tag: '降本', worker: '采购助手', due: '10 月 16 日' },
    ],
  },
  { col: '已完成', tasks: [{ title: '整理供应商议价依据', project: '采购报价智能比对', tag: '降本', worker: '采购助手', due: '今天 11:20' }] },
];

export const DIGITAL_WORKERS = [
  { icon: '质', name: '质量分析员', status: '在线', statusColor: 'bg-emerald-600', task: '追踪检验异常 · 3 项待复核' },
  { icon: '产', name: '排程助手', status: '试运行', statusColor: 'bg-sky-600', task: '辅助排程 · 等待主管确认' },
  { icon: '采', name: '采购助手', status: '试运行', statusColor: 'bg-sky-600', task: '比对重点物料 · 2 份新报告' },
];

export const COLLAB = {
  depts: ['生产运营部', '质量管理部', '供应链中心', '设备工程部'],
  members: [
    { icon: '李', name: '李经理', role: '业务负责人 · 结果确认' },
    { icon: '✧', name: '排程助手', role: '数字员工 · 辅助分析' },
    { icon: '工', name: '业务专员', role: '证据提供 · 结果复核' },
  ],
  chat: [
    { who: '李经理', time: '14:02', mine: true, text: '请整理「生产排程优化」当前的问题、依据和下一步建议。结果需要能直接用于今天的业务复盘。' },
    { who: '排程助手', time: '14:05', mine: false, text: '已整理本次分析。当前「订单准交率」为 94.6%，与目标 96% 仍有差距。建议先核验数据完整性，再由业务负责人确认下一步行动。' },
  ],
  deliverable: {
    title: '交付物 · 本期业务分析草案',
    basis: 'MES 工单 / ERP 订单 / WMS 库存',
    status: '待业务复核 · 未自动执行业务写入',
  },
  boundaries: [
    ['数据范围', '生产运营部'], ['运行方式', '辅助分析'], ['业务写入', '需主管确认'], ['对外发送', '需单独审批'],
  ],
  goal: { title: '订单准交率达到 96%', current: '94.6%', target: '目标 96%' },
};

export const fmtWan = (n: number) => (n >= 10000 ? `${(n / 10000).toFixed(1)} 万` : `${n}`);
