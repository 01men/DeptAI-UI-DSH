import { Plug, KeyRound, MonitorSmartphone, HardDrive, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { PLATFORM_CONN } from '@/data/mock';
import { SectionHead } from '@/components/shared';
import { Button } from '@/components/ui/button';

const PRINCIPALS = [
  { id: 'agent:quality-patrol', scopes: 'mcp.invoke, skill.read, agent.read, usage.write', tokens: 12, last: '10-14 10:32' },
  { id: 'app:sop-qa', scopes: 'usage.write', tokens: 4, last: '10-14 10:44' },
  { id: 'app:qtrace', scopes: 'mcp.invoke, usage.write', tokens: 3, last: '10-14 09:58' },
  { id: 'agent:aps-dispatch', scopes: 'mcp.invoke, skill.read, usage.write', tokens: 8, last: '10-14 10:28' },
];
const CLIENTS = [
  { name: '二厂边缘节点 · dsh web', version: 'v1.7.1', tools: 37, heartbeat: '2 分钟前', role: 'operator' },
  { name: '研发院笔记本 · dsh', version: 'v1.7.0', tools: 37, heartbeat: '14 分钟前', role: 'readonly' },
  { name: '供应链计划部工作站', version: 'v1.7.1', tools: 37, heartbeat: '1 小时前', role: 'operator' },
];

export default function PlatformAccess() {
  const c = PLATFORM_CONN;
  return (
    <div className="space-y-4">
      <SectionHead
        label="CONNECT"
        title="平台接入"
        extra="机器凭证 + OIDC 客户端 + 远程 dsh 客户端一处盘点 · 接入码一次性、只存哈希 · 凭证零进平台"
        actions={
          <Button size="sm" onClick={() => toast.info('接入码已创建', { description: 'enr_9f2e… · 15 分钟有效 · 仅此一次展示，平台只存哈希' })}>
            创建接入码
          </Button>
        }
      />

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        {/* open-connector */}
        <div className="rounded-lg border bg-card p-4">
          <SectionHead label="CONNECTOR / SAAS" title="SaaS 连接器网关" extra="open-connector sidecar v1.4.0 · 数据面 + 凭证保险库（AES-256-GCM）" />
          <div className="grid grid-cols-3 gap-2">
            {[
              ['Provider', '1,000+', '目录浏览已接通'],
              ['Action', '10,000+', 'riskLevel 徽章可见'],
              ['运行记录', '2,318', '28 天 run/meter 对账零不符'],
            ].map(([k, v, s]) => (
              <div key={k} className="rounded-md border p-3 text-center">
                <div className="tnum text-lg font-semibold">{v}</div>
                <div className="text-[11px] font-medium">{k}</div>
                <div className="mt-0.5 text-[10.5px] text-muted-foreground">{s}</div>
              </div>
            ))}
          </div>
          <div className="mt-3 space-y-2">
            {[
              ['ERP（SAP）', 'API Key 表单 · 过手不落盘', 'ok'],
              ['WMS 仓储', 'OAuth 代理全流程', 'ok'],
              ['CRM 客诉', 'no_auth 虚拟登记', 'warn'],
            ].map(([name, mode, st]) => (
              <div key={name} className="flex items-center justify-between rounded-md border px-3 py-2 text-[12.5px]">
                <span className="flex items-center gap-2"><Plug className="size-3.5 text-primary" />{name}</span>
                <span className="text-[11px] text-muted-foreground">{mode}</span>
                <span className={`size-[6px] rounded-full ${st === 'ok' ? 'bg-emerald-600' : 'bg-amber-500'}`} />
              </div>
            ))}
          </div>
        </div>

        {/* 机器凭证 */}
        <div className="rounded-lg border bg-card p-4">
          <SectionHead label="MACHINE PRINCIPALS" title="机器凭证" extra="clientSecret 仅存哈希 · 调整 scopes 联动吊销存量令牌" />
          <div className="space-y-2">
            {PRINCIPALS.map((p) => (
              <div key={p.id} className="rounded-md border px-3 py-2.5">
                <div className="flex items-center justify-between">
                  <span className="mono text-[12px] font-medium">{p.id}</span>
                  <Button
                    variant="ghost" size="sm" className="h-6 px-2 text-[11px]"
                    onClick={() => toast.success('已轮换 clientSecret', { description: `${p.id} · clientId 不变 · 旧值立即失效 · 新值仅此一次返回` })}
                  >
                    <RefreshCw className="mr-1 size-3" /> 轮换
                  </Button>
                </div>
                <div className="mt-1 flex flex-wrap items-center gap-x-3 text-[11px] text-muted-foreground">
                  <span className="mono">{p.scopes}</span>
                  <span className="tnum">活跃令牌 {p.tokens}</span>
                  <span className="tnum ml-auto">{p.last}</span>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-3 flex items-center gap-2 rounded-md bg-muted/50 p-2.5 text-[11px] text-muted-foreground">
            <KeyRound className="size-3.5 shrink-0" />
            OIDC 客户端 {c.oidcClients} 个 · 全部通过上线门禁双点复核 · discovery / JWKS / end_session 全链可用
          </div>
        </div>
      </div>

      {/* 远程 dsh + NAS */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <div className="rounded-lg border bg-card p-4">
          <SectionHead label="REMOTE DSH" title="远程 dsh 客户端" extra="37 个运维工具远程代理到宿主 · 权限按模板收敛 · 全程审计" />
          <div className="space-y-2">
            {CLIENTS.map((cl) => (
              <div key={cl.name} className="flex items-center gap-3 rounded-md border px-3 py-2.5 text-[12.5px]">
                <MonitorSmartphone className="size-4 shrink-0 text-primary" />
                <div className="min-w-0 flex-1">
                  <div className="truncate font-medium">{cl.name}</div>
                  <div className="text-[11px] text-muted-foreground"><span className="mono">{cl.version}</span> · {cl.tools} 工具 · 模板 <span className="mono">{cl.role}</span></div>
                </div>
                <span className="flex items-center gap-1.5 text-[11px] text-emerald-700">
                  <span className="size-[6px] rounded-full bg-emerald-600 pulse-dot" /> 心跳 {cl.heartbeat}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-lg border bg-card p-4">
          <SectionHead label="NAS / FILES" title="NAS 资产" extra="经 MCP 文件网关 · 不直连 DSM 私有 API · 数据权限引擎 35 格矩阵" />
          <div className="space-y-2">
            {[
              ['质检图片库', 'nas:quality-img', '18.2 TB · 5 个共享 · RBAC 到班组', 'healthy'],
              ['工艺文件库', 'nas:process-doc', '6.4 TB · 2 个共享 · Skill 包后端', 'healthy'],
            ].map(([name, key, meta, h]) => (
              <div key={key} className="flex items-center gap-3 rounded-md border px-3 py-2.5">
                <HardDrive className={`size-4 shrink-0 ${h === 'healthy' ? 'text-emerald-600' : 'text-amber-600'}`} />
                <div className="min-w-0 flex-1">
                  <div className="text-[13px] font-medium">{name}</div>
                  <div className="text-[11px] text-muted-foreground">{meta}</div>
                </div>
                <span className="mono text-[11px] text-muted-foreground">{key}</span>
              </div>
            ))}
          </div>
          <div className="mt-3 grid grid-cols-3 gap-2 text-center text-[11px]">
            {[['HMAC 签名链接', '4 档有效期'], ['所有权跟踪', '上传 / 改名 / 删除'], ['灰度引擎', 'observeOnly → 强制']].map(([t1, d]) => (
              <div key={t1} className="rounded-md bg-muted/50 p-2">
                <div className="font-medium">{t1}</div>
                <div className="mt-0.5 text-muted-foreground">{d}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
