import { useState } from 'react';
import {
  Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerClose,
} from '@/components/ui/drawer';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { GitBranch, KeyRound, ShieldCheck, Activity, ScrollText, Info } from 'lucide-react';
import type { Asset, Lifecycle } from '@/data/mock';
import { AUDIT_LOGS, LIFECYCLE_LABEL } from '@/data/mock';
import { HealthDot, LifecycleBadge, TypeBadge, GrayProgress, Sparkline } from './shared';
import { Button } from '@/components/ui/button';

function KV({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-6 py-2">
      <dt className="shrink-0 text-xs text-muted-foreground">{k}</dt>
      <dd className="text-right text-[13px]">{v}</dd>
    </div>
  );
}

const SCOPE_LABEL: Record<string, string> = {
  'mcp.invoke': '调用 MCP 服务',
  'skill.read': '读取 Skill',
  'agent.read': '读取 Agent 台账',
  'usage.write': '自推计量事件',
  'connector.invoke': '执行连接器动作',
};

export default function AssetDrawer({
  asset, open, onClose,
}: { asset: Asset | null; open: boolean; onClose: () => void }) {
  const [tab, setTab] = useState('overview');
  if (!asset) return null;
  const logs = AUDIT_LOGS.filter((l) => l.target === asset.key || l.actChain.join(' ').includes(asset.key)).slice(0, 5);

  return (
    <Drawer open={open} onOpenChange={(o) => !o && onClose()} direction="right">
      <DrawerContent className="!max-w-2xl overflow-y-auto">
        <DrawerHeader className="border-b px-6 pb-4">
          <div className="flex items-start justify-between gap-4 pr-8">
            <div>
              <div className="mb-1.5 flex items-center gap-2">
                <TypeBadge type={asset.type} />
                <LifecycleBadge s={asset.lifecycle} />
                {asset.grayPercent !== undefined && <GrayProgress percent={asset.grayPercent} />}
              </div>
              <DrawerTitle className="text-lg">{asset.name}</DrawerTitle>
              <div className="tnum mono mt-1 text-xs text-muted-foreground">{asset.key}</div>
            </div>
            <HealthDot health={asset.health} pulse />
          </div>
          <DrawerClose className="absolute right-4 top-4 rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground" />
        </DrawerHeader>

        <Tabs value={tab} onValueChange={setTab} className="px-6 py-4">
          <TabsList className="h-8 w-full justify-start rounded-md bg-muted/60 p-0.5">
            {[
              ['overview', '概览', Info], ['monitor', '监控', Activity], ['perm', '权限', KeyRound],
              ['topology', '拓扑', GitBranch], ['audit', '审计', ScrollText], ['lifecycle', '生命周期', ShieldCheck],
            ].map(([v, label, Icon]: any) => (
              <TabsTrigger key={v} value={v} className="h-7 flex-1 gap-1 rounded px-2 text-xs">
                <Icon className="size-3.5" /> {label}
              </TabsTrigger>
            ))}
          </TabsList>

          {/* 概览 */}
          <TabsContent value="overview" className="mt-4 space-y-5">
            <p className="rounded-md bg-muted/50 p-3 text-[13px] leading-relaxed text-muted-foreground">{asset.desc}</p>
            <dl className="divide-y">
              <KV k="归属组织" v={asset.org} />
              <KV k="负责人" v={asset.owner} />
              {asset.version && <KV k="当前版本" v={<span className="mono">{asset.version}</span>} />}
              {asset.autonomy && <KV k="自治级别" v={<span className="mono">{asset.autonomy}（{asset.autonomy === 'A2' ? '模板内自主，超模板转人工' : asset.autonomy === 'A1' ? '点名直调，人机协同' : '仅人工触发'}）</span>} />}
              <KV k="近 30 天调用" v={<span className="tnum mono">{asset.calls30d.toLocaleString()}</span>} />
              <KV k="近 30 天消耗" v={<span className="tnum mono">{asset.tokens30d.toLocaleString()} 万 tokens</span>} />
              <KV k="成本参考" v={<span className="tnum mono">¥ {asset.cost30d.toLocaleString()}（零价快照 · 内部采购成本参考）</span>} />
              {asset.dau !== undefined && <KV k="DAU" v={<span className="tnum mono">{asset.dau.toLocaleString()}</span>} />}
            </dl>
            <div className="flex gap-2 border-t pt-4">
              <Button size="sm" onClick={() => toast.success('dry-run 预演通过', { description: `对 ${asset.key} 的影响面：0 冲突，0 调用失败，已留痕` })}>
                下线 dry-run
              </Button>
              <Button size="sm" variant="outline" onClick={() => toast.success('巡检完成', { description: `${asset.key} 探活通过，结果已写入 audit` })}>
                健康巡检
              </Button>
            </div>
          </TabsContent>

          {/* 监控 */}
          <TabsContent value="monitor" className="mt-4 space-y-4">
            <div>
              <div className="micro-label mb-2">近 14 天调用量</div>
              <Sparkline data={asset.trend} className="h-[72px] w-full" />
            </div>
            <div className="grid grid-cols-3 gap-2">
              {[
                ['成功率', asset.health === 'warning' ? '91.2%' : asset.health === 'critical' ? '—（熔断）' : '99.7%'],
                ['P95 延迟', asset.health === 'warning' ? '1,240 ms' : '860 ms'],
                ['今日调用', asset.trend[13].toLocaleString()],
              ].map(([k, v]) => (
                <div key={k} className="rounded-md border p-3 text-center">
                  <div className="tnum text-[15px] font-semibold">{v}</div>
                  <div className="mt-0.5 text-[11px] text-muted-foreground">{k}</div>
                </div>
              ))}
            </div>
            {asset.health === 'critical' && (
              <div className="rounded-md border border-red-200 bg-red-50 p-3 text-xs leading-relaxed text-red-700">
                连续 3 次探活失败，熔断已打开；业务成功即半闭合。最近错误：ECONNREFUSED 192.168.4.21:8931（initialize 超时 5s）。
              </div>
            )}
          </TabsContent>

          {/* 权限 */}
          <TabsContent value="perm" className="mt-4 space-y-4">
            <div className="rounded-md border p-3">
              <div className="mb-2 text-[13px] font-medium">机器凭证 scopes</div>
              <div className="flex flex-wrap gap-1.5">
                {Object.entries(SCOPE_LABEL).slice(0, asset.type === 'agent' ? 4 : 2).map(([s, label]) => (
                  <span key={s} className="rounded bg-muted px-2 py-1 text-[11px]">
                    <span className="mono text-primary">{s}</span>
                    <span className="ml-1.5 text-muted-foreground">{label}</span>
                  </span>
                ))}
              </div>
              <p className="mt-2 text-[11px] text-muted-foreground">clientSecret 仅存哈希 · 轮换后旧值立即失效 · 支持一键轮换</p>
            </div>
            <div className="rounded-md border p-3">
              <div className="mb-2 text-[13px] font-medium">授权主体</div>
              <div className="space-y-1.5 text-[13px]">
                <div className="flex justify-between"><span>组织范围</span><span className="text-muted-foreground">{asset.org}</span></div>
                <div className="flex justify-between"><span>负责人（owner）</span><span className="text-muted-foreground">{asset.owner}</span></div>
                <div className="flex justify-between"><span>场景级授权</span><span className="mono text-muted-foreground">sceneCode: {asset.type}.read（deny→allow→fail-closed）</span></div>
              </div>
            </div>
          </TabsContent>

          {/* 拓扑 */}
          <TabsContent value="topology" className="mt-4">
            <div className="micro-label mb-3">编排拓扑 · 一图穿透</div>
            <svg viewBox="0 0 560 220" className="w-full rounded-md border bg-muted/30">
              {asset.type === 'app' || asset.type === 'agent' ? (
                <>
                  <g>
                    <rect x="30" y="86" width="130" height="44" rx="6" fill="white" stroke="hsl(40 9% 82%)" />
                    <text x="95" y="104" textAnchor="middle" fontSize="12" fontWeight="600">{asset.name}</text>
                    <text x="95" y="120" textAnchor="middle" fontSize="9" fill="hsl(30 4% 42%)" className="mono">{asset.key}</text>
                  </g>
                  <line x1="160" y1="108" x2="230" y2="60" stroke="hsl(201 88% 31%)" strokeWidth="1.4" />
                  <line x1="160" y1="108" x2="230" y2="160" stroke="hsl(201 88% 31%)" strokeWidth="1.4" />
                  <g>
                    <rect x="230" y="38" width="140" height="44" rx="6" fill="white" stroke="hsl(40 9% 82%)" />
                    <text x="300" y="56" textAnchor="middle" fontSize="11.5" fontWeight="600">模型路由</text>
                    <text x="300" y="71" textAnchor="middle" fontSize="9" fill="hsl(30 4% 42%)" className="mono">model:deepseek-v3.2</text>
                  </g>
                  <g>
                    <rect x="230" y="138" width="140" height="44" rx="6" fill="white" stroke="hsl(40 9% 82%)" />
                    <text x="300" y="156" textAnchor="middle" fontSize="11.5" fontWeight="600">MCP 服务</text>
                    <text x="300" y="171" textAnchor="middle" fontSize="9" fill="hsl(30 4% 42%)" className="mono">mcp:vision-quality</text>
                  </g>
                  <line x1="370" y1="60" x2="440" y2="100" stroke="hsl(40 6% 65%)" strokeWidth="1.2" strokeDasharray="4 3" />
                  <g>
                    <rect x="440" y="80" width="96" height="40" rx="6" fill="white" stroke="hsl(40 9% 82%)" />
                    <text x="488" y="97" textAnchor="middle" fontSize="11" fontWeight="600">Skill</text>
                    <text x="488" y="111" textAnchor="middle" fontSize="9" fill="hsl(30 4% 42%)" className="mono">skill:defect-sop</text>
                  </g>
                </>
              ) : (
                <g>
                  <rect x="200" y="80" width="160" height="52" rx="6" fill="white" stroke="hsl(201 88% 31%)" strokeWidth="1.4" />
                  <text x="280" y="102" textAnchor="middle" fontSize="12.5" fontWeight="600">{asset.name}</text>
                  <text x="280" y="119" textAnchor="middle" fontSize="9.5" fill="hsl(30 4% 42%)" className="mono">{asset.key} · {asset.version ?? '—'}</text>
                </g>
              )}
            </svg>
            <p className="mt-2 text-[11px] text-muted-foreground">依赖变更必发事件；跨插件联动只经事件总线（platformBus），禁止直连数据。</p>
          </TabsContent>

          {/* 审计 */}
          <TabsContent value="audit" className="mt-4">
            {logs.length === 0 ? (
              <p className="py-8 text-center text-[13px] text-muted-foreground">近 24h 与该资产相关的审计事件为 0（人类读操作不计入，噪音控制）</p>
            ) : (
              <div className="space-y-2">
                {logs.map((l) => (
                  <div key={l.id} className="rounded-md border p-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[13px] font-medium">{l.action}</span>
                      <span className={`tnum mono text-[10.5px] ${l.result === 'deny' ? 'text-amber-700' : l.result === 'alert' ? 'text-red-700' : 'text-emerald-700'}`}>{l.result.toUpperCase()}</span>
                    </div>
                    <div className="mt-1.5 flex flex-wrap items-center gap-1">
                      {l.actChain.map((c, i) => (
                        <span key={i} className="flex items-center gap-1">
                          <span className="mono rounded bg-muted px-1.5 py-0.5 text-[10.5px]">{c}</span>
                          {i < l.actChain.length - 1 && <span className="text-muted-foreground">→</span>}
                        </span>
                      ))}
                    </div>
                    <div className="tnum mono mt-1.5 text-[11px] text-muted-foreground">{l.time} · {l.id}</div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          {/* 生命周期 */}
          <TabsContent value="lifecycle" className="mt-4 space-y-4">
            <div>
              <div className="micro-label mb-3">生命周期状态机 · L4 护栏</div>
              <div className="flex items-center">
                {(['draft', 'online', 'offline', 'archived'] as Lifecycle[]).map((s, i) => {
                  const order: Lifecycle[] = ['draft', 'online', 'offline', 'archived'];
                  const cur = order.indexOf(asset.lifecycle === 'deprecated' ? 'offline' : asset.lifecycle);
                  return (
                    <div key={s} className="flex flex-1 items-center last:flex-none">
                      <div className="flex flex-col items-center">
                        <span className={`flex size-6 items-center justify-center rounded-full text-[10px] font-semibold ${
                          i < cur ? 'bg-emerald-600 text-white' : i === cur ? 'bg-primary text-white' : 'bg-muted text-muted-foreground'
                        }`}>{i < cur ? '✓' : i + 1}</span>
                        <span className={`mt-1 text-[10.5px] ${i === cur ? 'font-medium text-foreground' : 'text-muted-foreground'}`}>
                          {LIFECYCLE_LABEL[s]}
                        </span>
                      </div>
                      {i < 3 && <div className={`mx-1 mb-4 h-px flex-1 ${i < cur ? 'bg-emerald-500' : 'bg-border'}`} />}
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="rounded-md border p-3 text-[12.5px] leading-relaxed text-muted-foreground">
              上线 / 下线 / 下架 / 吊销均强制 L4 审批单，执行结果回写；危险操作提供 dry-run 影响面预览与原因必填，审批全程时间线留痕。
            </div>
            {asset.lifecycle === 'draft' ? (
              <Button className="w-full" onClick={() => toast.info('已生成 L4 审批单', { description: '补齐「数据出域评估」与「负责人确认」后提交' })}>
                补全治理属性并提交上线
              </Button>
            ) : (
              <Button variant="outline" className="w-full" onClick={() => toast.info('已生成 L4 下线审批单（dry-run 已通过）')}>
                发起下线审批
              </Button>
            )}
          </TabsContent>
        </Tabs>
      </DrawerContent>
    </Drawer>
  );
}
