import { useMemo, useState } from 'react';
import { Search, ShieldCheck, Download, CircleAlert } from 'lucide-react';
import { toast } from 'sonner';
import { MARKET_ITEMS } from '@/data/mock';
import type { MarketItem } from '@/data/mock';
import { SectionHead } from '@/components/shared';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerClose,
} from '@/components/ui/drawer';

const CATS = ['全部', '质量', '设备', '供应链', '工艺', '安全', '经营', '协同'];

function HeatStrip({ heat, big }: { heat: number[]; big?: boolean }) {
  const max = Math.max(...heat, 1);
  const cell = big ? 'size-[13px]' : 'size-[7px]';
  return (
    <div className="flex flex-wrap gap-[2px]">
      {heat.map((v, i) => (
        <span
          key={i}
          className={`${cell} rounded-[2px]`}
          style={{ background: v === 0 ? 'hsl(45 10% 92%)' : `hsl(201 88% ${68 - (v / max) * 40}%)` }}
          title={`第 ${i + 1} 天 · ${v} 次`}
        />
      ))}
    </div>
  );
}

const STATUS_STYLE: Record<MarketItem['status'], string> = {
  已上架: 'text-emerald-700 bg-emerald-600/10',
  审批中: 'text-sky-700 bg-sky-600/10',
  已弃用: 'text-amber-700 bg-amber-500/10',
};

export default function Market() {
  const [cat, setCat] = useState('全部');
  const [q, setQ] = useState('');
  const [item, setItem] = useState<MarketItem | null>(null);

  const items = useMemo(
    () => MARKET_ITEMS.filter((m) => (cat === '全部' || m.category === cat) && (!q || m.name.includes(q) || m.publisher.includes(q))),
    [cat, q],
  );

  return (
    <div>
      <SectionHead
        label="SKILL MARKET"
        title="AI 市场"
        extra="提交 → 静态扫描 → 两级审批 → 版本化上架 · 契约五面 Ed25519 验签 · 色深 = 当日使用次数（30 天热力）"
        actions={
          <Button size="sm" onClick={() => toast.info('脚手架已就绪', { description: 'plugin init：契约五面 + 发布者密钥对已生成' })}>
            提交新技能
          </Button>
        }
      />

      <div className="mb-4 flex flex-wrap items-center gap-2">
        {CATS.map((c) => (
          <button
            key={c}
            onClick={() => setCat(c)}
            className={`rounded-full px-3 py-1 text-[12.5px] transition-colors ${
              cat === c ? 'bg-foreground text-background' : 'bg-card text-muted-foreground ring-1 ring-border hover:text-foreground'
            }`}
          >
            {c}
          </button>
        ))}
        <div className="relative ml-auto">
          <Search className="absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="搜索技能 / 发布者"
            className="h-8 w-48 rounded-md border bg-card pl-8 pr-3 text-[12.5px] outline-none ring-primary/30 placeholder:text-muted-foreground/70 focus:ring-2"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
        {items.map((m) => (
          <button
            key={m.id}
            onClick={() => setItem(m)}
            className="group rounded-lg border bg-card p-4 text-left transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-[0_8px_24px_-12px_hsl(30_8%_12%/0.18)]"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="truncate text-[14px] font-semibold">{m.name}</span>
                  {m.verified && <ShieldCheck className="size-3.5 shrink-0 text-emerald-600" />}
                </div>
                <div className="mt-0.5 truncate text-[11.5px] text-muted-foreground">{m.publisher}</div>
              </div>
              <span className={`shrink-0 rounded-full px-2 py-0.5 text-[11px] font-medium ${STATUS_STYLE[m.status]}`}>{m.status}</span>
            </div>

            <p className="mt-2.5 line-clamp-2 min-h-8 text-[12.5px] leading-relaxed text-muted-foreground">{m.desc}</p>

            <div className="mt-3">
              <HeatStrip heat={m.heat} />
            </div>

            <div className="mt-3 flex items-center justify-between border-t pt-2.5 text-[11.5px] text-muted-foreground">
              <span className="flex items-center gap-3">
                <span className="mono">{m.version}</span>
                <span className="flex items-center gap-1"><Download className="size-3" />{m.installs}</span>
                <span className={`rounded px-1 py-0.5 text-[10px] font-medium ${
                  m.risk === '高风险' ? 'bg-red-600/10 text-red-700' : m.risk === '中风险' ? 'bg-amber-500/10 text-amber-700' : 'bg-emerald-600/10 text-emerald-700'
                }`}>{m.risk}</span>
              </span>
              <span className="text-primary opacity-0 transition-opacity group-hover:opacity-100">详情 →</span>
            </div>
          </button>
        ))}
      </div>

      {/* 详情抽屉 */}
      <Drawer open={!!item} onOpenChange={(o) => !o && setItem(null)} direction="right">
        {item && (
          <DrawerContent className="!max-w-xl overflow-y-auto">
            <DrawerHeader className="border-b px-6 pb-4">
              <div className="flex items-center justify-between pr-8">
                <div>
                  <div className="mb-1.5 flex items-center gap-2">
                    <span className={`rounded-full px-2 py-0.5 text-[11px] font-medium ${STATUS_STYLE[item.status]}`}>{item.status}</span>
                    {item.verified && <span className="flex items-center gap-1 text-[11px] text-emerald-700"><ShieldCheck className="size-3.5" /> Ed25519 验签通过</span>}
                  </div>
                  <DrawerTitle className="text-lg">{item.name}</DrawerTitle>
                  <div className="mt-1 text-xs text-muted-foreground">{item.publisher} · {item.category} · <span className="mono">{item.version}</span></div>
                </div>
              </div>
              <DrawerClose className="absolute right-4 top-4 rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground" />
            </DrawerHeader>
            <div className="space-y-5 px-6 py-5">
              <p className="rounded-md bg-muted/50 p-3 text-[13px] leading-relaxed text-muted-foreground">{item.desc}</p>

              <div>
                <div className="micro-label mb-2">30 天使用热力</div>
                <HeatStrip heat={item.heat} big />
                <p className="mt-1.5 text-[11px] text-muted-foreground">usage 事件为主、计量接入前下载流水按日回填去重</p>
              </div>

              <div>
                <div className="micro-label mb-2">上架流水线</div>
                <div className="space-y-0">
                  {[
                    ['提交', `${item.publisher.split(' · ')[1] ?? item.publisher} 提交 ${item.version}`, true],
                    ['静态扫描', item.risk === '高风险' ? '通过 · 命中「成本数据出域」规则' : '恶意代码 0 命中 / 密钥泄露 0 命中', item.status !== '审批中'],
                    ['两级审批', item.status === '已上架' ? '安全评审 + 管理员终审均通过' : item.status === '审批中' ? '等待安全加签' : '已完成（历史版本）', item.status === '已上架' || item.status === '已弃用'],
                    ['版本化上架', `包存储：NAS 工艺文件库 /skillhub · ${item.installs} 次安装`, item.status === '已上架' || item.status === '已弃用'],
                  ].map(([step, desc, done]: any, i) => (
                    <div key={step} className="relative flex gap-3 pb-4 last:pb-0">
                      {i < 3 && <span className={`absolute left-[9px] top-5 h-full w-px ${done ? 'bg-emerald-500' : 'bg-border'}`} />}
                      <span className={`relative mt-0.5 flex size-[19px] shrink-0 items-center justify-center rounded-full text-[10px] ${done ? 'bg-emerald-600 text-white' : 'bg-muted text-muted-foreground'}`}>
                        {done ? '✓' : i + 1}
                      </span>
                      <div>
                        <div className="text-[13px] font-medium">{step}</div>
                        <div className="text-[11.5px] text-muted-foreground">{desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {item.status === '已弃用' && (
                <div className="flex items-start gap-2 rounded-md border border-amber-200 bg-amber-50 p-3 text-xs leading-relaxed text-amber-800">
                  <CircleAlert className="mt-0.5 size-3.5 shrink-0" />
                  弃用原因：重复建设（被官方连接器替代）。3 个引用 Agent 已触发迁移告警，2026-11-30 后不再维护。
                </div>
              )}

              <div className="flex gap-2 border-t pt-4">
                {item.status === '已上架' && (
                  <Button size="sm" onClick={() => toast.success(`已安装 ${item.name}`, { description: '安装登记依赖关系，调用自动产生 usage 事件（meter: calls）' })}>
                    <Download className="mr-1 size-3.5" /> 安装到团队
                  </Button>
                )}
                {item.status === '审批中' && <Badge variant="secondary">等待安全加签 · ap-1041</Badge>}
                <Button size="sm" variant="outline" onClick={() => toast.info('版本历史', { description: `${item.name} 共 ${item.version.startsWith('v0') ? 3 : 6} 个历史版本，均不可变` })}>
                  版本历史
                </Button>
              </div>
            </div>
          </DrawerContent>
        )}
      </Drawer>
    </div>
  );
}
