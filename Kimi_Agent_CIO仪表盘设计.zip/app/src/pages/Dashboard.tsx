import { useMemo, useState } from 'react';
import {
  ArrowRight, ArrowUpRight, Bell, Bot, Check, CircleCheck, Download,
  FileCheck2, Landmark, MessageSquareText, Radio, Send, ShieldAlert, Sparkles, Zap,
} from 'lucide-react';
import { toast } from 'sonner';
import {
  ACTION_PROJECTS, ASSETS, ASSET_TYPE_LABEL, AUDIT_LOGS, APPROVALS,
  BIZ_KPIS, COLLAB, DAILY_CALLS, DAILY_COST, DAILY_TOKENS, DECISIONS, DEPT_USAGE,
  DIGITAL_WORKERS, FACTORIES, GOALS, INSIGHT, TASK_KANBAN, VERIFY_RULES,
  VALUE_ACTUAL, VALUE_LABELS, VALUE_TARGET,
} from '@/data/mock';
import type { AssetType } from '@/data/mock';
import {
  AreaChart, Donut, DualTrendChart, HBarList, SectionHead, Stat,
} from '@/components/shared';
import type { PageProps } from '@/App';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const TYPE_COLORS: Record<AssetType, string> = {
  mcp: '#0e7490', agent: '#7c3aed', app: '#2563eb', skill: '#059669', model: '#d97706', nas: '#e11d48',
};

const PROJ_STATUS: Record<string, string> = {
  进行中: 'bg-sky-600/10 text-sky-700 ring-sky-600/25',
  需关注: 'bg-amber-500/10 text-amber-700 ring-amber-500/30',
  待验收: 'bg-emerald-600/10 text-emerald-700 ring-emerald-600/25',
};
const TAG_STYLE: Record<string, string> = {
  降本: 'bg-amber-500/10 text-amber-700',
  提质: 'bg-emerald-600/10 text-emerald-700',
  增效: 'bg-sky-600/10 text-sky-700',
};

const TABS = [
  { key: 'cockpit', label: '经营驾驶舱', badge: `${DECISIONS.length} 待决策`, tone: 'amber' as const },
  { key: 'goals', label: '目标与价值' },
  { key: 'actions', label: '行动项目', badge: `${ACTION_PROJECTS.length}`, tone: 'plain' as const },
  { key: 'collab', label: '人机协作', badge: `${DIGITAL_WORKERS.length} 位`, tone: 'plain' as const },
  { key: 'ops', label: '平台运行' },
];
type TabKey = (typeof TABS)[number]['key'];

export default function Dashboard({ go }: PageProps) {
  const [tab, setTab] = useState<TabKey>('cockpit');
  const [factory, setFactory] = useState(FACTORIES[0]);
  const [period, setPeriod] = useState('本月');
  const [projFilter, setProjFilter] = useState<'全部项目' | '需关注' | '待验收'>('全部项目');

  const online = ASSETS.filter((a) => a.lifecycle === 'online').length;
  const crit = ASSETS.filter((a) => a.health === 'critical').length;
  const warn = ASSETS.filter((a) => a.health === 'warning').length;

  const typeShare = useMemo(() => {
    const m = new Map<AssetType, number>();
    ASSETS.forEach((a) => m.set(a.type, (m.get(a.type) || 0) + a.cost30d));
    return Array.from(m.entries())
      .filter(([, v]) => v > 0)
      .sort((x, y) => y[1] - x[1])
      .map(([type, v]) => ({ label: ASSET_TYPE_LABEL[type], value: Math.round(v), color: TYPE_COLORS[type] }));
  }, []);

  const labels = Array.from({ length: 28 }, (_, i) => `9-${String(17 + i).padStart(2, '0')}`);
  const projects = ACTION_PROJECTS.filter((p) => projFilter === '全部项目' || p.status === projFilter);

  return (
    <div className="space-y-4">
      {/* ============ 横向标签页 ============ */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1 rounded-lg bg-muted/60 p-1">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={cn(
                'flex items-center gap-1.5 rounded-md px-3 py-1.5 text-[12.5px] transition-colors',
                tab === t.key ? 'bg-card font-medium text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground',
              )}
            >
              {t.label}
              {t.badge && (
                <span
                  className={cn(
                    'tnum mono rounded-full px-1.5 py-px text-[10px]',
                    tab === t.key
                      ? t.tone === 'amber' ? 'bg-amber-500/15 text-amber-700' : 'bg-muted text-muted-foreground'
                      : 'bg-card text-muted-foreground ring-1 ring-border',
                  )}
                >
                  {t.badge}
                </span>
              )}
            </button>
          ))}
        </div>
        <span className="ml-auto hidden text-[11px] text-muted-foreground lg:block">
          {tab === 'cockpit' && '先看全局，再下钻目标、行动与人机协作'}
          {tab === 'goals' && '每项行动，都有一个经营理由'}
          {tab === 'actions' && '目标 → 行动 → 交付 → 验收'}
          {tab === 'collab' && '人负责判断，数字员工负责交付'}
          {tab === 'ops' && '元冰可 AIOS 资源与治理口径 · 用量透明与内部成本穿透'}
        </span>
      </div>

      {/* ============ 标签内容 ============ */}
      <div key={tab} className="fade-up space-y-4">
        {tab === 'cockpit' && (
          <>
            {/* S0 · 经营洞察与异常 */}
            <div className="grid grid-cols-1 gap-4 xl:grid-cols-5">
              <div className="rounded-lg border bg-card p-4 xl:col-span-3">
                <div className="flex items-start gap-3">
                  <span className="flex size-8 shrink-0 items-center justify-center rounded-md bg-primary/10 text-primary">
                    <Sparkles className="size-4" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="micro-label">今日经营洞察</div>
                    <p className="mt-1 text-[13.5px] leading-relaxed">{INSIGHT.text}</p>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => setTab('actions')}>
                    查看行动 <ArrowRight className="ml-1 size-3.5" />
                  </Button>
                </div>
              </div>
              <div className="rounded-lg border bg-card p-4 xl:col-span-2">
                <div className="flex items-center justify-between">
                  <div className="micro-label flex items-center gap-1.5">
                    <Bell className="size-3" /> 运行与业务影响
                  </div>
                  <span className="tnum text-[11px] text-muted-foreground">2 项异常需要处置 · 0 项批准待执行</span>
                </div>
                <div className="mt-2.5 space-y-2">
                  {INSIGHT.exceptions.map((e) => (
                    <div key={e.name} className="flex items-center gap-2.5 rounded-md border px-3 py-2">
                      <span className={cn('size-[7px] shrink-0 rounded-full', e.level === 'critical' ? 'bg-red-600 pulse-dot' : 'bg-amber-500')}
                        style={e.level === 'critical' ? { ['--dot-color' as string]: '4 72% 51%' } : undefined} />
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-[12.5px] font-medium">{e.name}</div>
                        <div className="text-[11px] text-muted-foreground">{e.chain} · {e.owner}</div>
                      </div>
                      <button
                        className="shrink-0 text-[11px] text-primary hover:underline"
                        onClick={() => toast.info('影响面分析', { description: `${e.name}：依赖链路与受影响行动已下钻（演示）` })}
                      >
                        看影响 ›
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* 口径工具条 */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="micro-label mr-1">经营口径</span>
              {[
                { value: factory, options: FACTORIES, set: (v: string) => { setFactory(v); toast.info(`已切换：${v}`, { description: '演示数据为集团口径，切换后数字保持不变' }); } },
                { value: period, options: ['本月', '近三个月'], set: setPeriod },
              ].map((sel, i) => (
                <select
                  key={i}
                  value={sel.value}
                  onChange={(e) => sel.set(e.target.value)}
                  className="h-7 rounded-md border bg-card px-2 text-[12px] text-muted-foreground outline-none focus:ring-2 focus:ring-primary/30"
                >
                  {sel.options.map((o) => <option key={o}>{o}</option>)}
                </select>
              ))}
              <Button variant="outline" size="sm" className="ml-auto" onClick={() => toast.success('经营简报已生成', { description: '集团口径 · 2 项待决策 · 4 项重点行动 · 可下载最终版（演示）' })}>
                <Download className="mr-1 size-3.5" /> 经营简报
              </Button>
            </div>

            {/* S1 · 经营 KPI */}
            <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
              {BIZ_KPIS.map((k) => (
                <div key={k.label} className="rounded-lg border bg-card p-4">
                  <div className="micro-label">{k.label}</div>
                  <div className="tnum mt-1.5 text-[24px] font-semibold leading-none tracking-tight">
                    {k.value} <span className="text-[13px] font-medium text-muted-foreground">{k.unit}</span>
                  </div>
                  {k.kind === 'budget' ? (
                    <div className="mt-2.5">
                      <div className="h-1.5 overflow-hidden rounded-full bg-stone-100">
                        <div className="h-full rounded-full bg-gradient-to-r from-sky-700 to-cyan-500" style={{ width: `${k.used}%` }} />
                      </div>
                      <div className="mt-1.5 text-[11px] text-muted-foreground">{k.delta} · {k.deltaLabel}</div>
                    </div>
                  ) : (
                    <div className="mt-2 text-[11.5px]">
                      <span className="font-medium text-emerald-700">{k.delta}</span>
                      <span className="ml-1.5 text-muted-foreground">{k.deltaLabel}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* S3 · 价值兑现趋势 + 需要您决策 */}
            <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
              <div className="rounded-lg border bg-card p-4 xl:col-span-2">
                <SectionHead
                  label="VALUE / TRACKING"
                  title="AI 价值兑现趋势"
                  extra="从应用投入，追踪到业务结果 · 演示快照：核验价值与目标共用尺度"
                  actions={
                    <div className="flex items-center gap-4 text-[11px] text-muted-foreground">
                      <span className="flex items-center gap-1.5"><span className="h-[2px] w-4 rounded bg-primary" /> 核验价值</span>
                      <span className="flex items-center gap-1.5"><span className="h-[2px] w-4 rounded bg-stone-400 [background:repeating-linear-gradient(90deg,hsl(30_4%_55%)_0_4px,transparent_4px_7px)]" /> 目标</span>
                    </div>
                  }
                />
                <div className="mb-2 flex items-baseline gap-8">
                  <div>
                    <div className="text-[10.5px] text-muted-foreground">累计已核验价值</div>
                    <div className="tnum text-[20px] font-semibold">126.8 <span className="text-xs font-normal text-muted-foreground">万元</span></div>
                  </div>
                  <div>
                    <div className="text-[10.5px] text-muted-foreground">本期 AI 使用成本</div>
                    <div className="tnum text-[20px] font-semibold">1.84 <span className="text-xs font-normal text-muted-foreground">万元</span></div>
                  </div>
                  <div className="tnum ml-auto hidden text-[11px] text-muted-foreground md:block">单位：万元 · {factory}</div>
                </div>
                <DualTrendChart actual={VALUE_ACTUAL} target={VALUE_TARGET} labels={VALUE_LABELS} unit="万元" />
              </div>

              <div className="rounded-lg border bg-card p-4">
                <SectionHead
                  label="DECISION / 02"
                  title="需要您决策"
                  actions={<Button variant="ghost" size="sm" onClick={() => go('approvals')}>全部决策 <ArrowRight className="ml-1 size-3.5" /></Button>}
                />
                <div className="space-y-2">
                  {DECISIONS.map((d) => (
                    <button
                      key={d.title}
                      onClick={() => go('approvals')}
                      className="flex w-full items-center gap-3 rounded-md border p-3 text-left transition-colors hover:border-primary/40 hover:bg-muted/40"
                    >
                      <span className={cn(
                        'flex size-8 shrink-0 items-center justify-center rounded-md',
                        d.icon === 'arrow' ? 'bg-amber-500/10 text-amber-700' : 'bg-emerald-600/10 text-emerald-700',
                      )}>
                        {d.icon === 'arrow' ? <ArrowUpRight className="size-4" /> : <Check className="size-4" />}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[13px] font-medium">{d.title}</span>
                        <span className="mt-0.5 block text-[11px] text-muted-foreground">{d.org} · {d.type} · {d.time}</span>
                      </span>
                      <ChevronRightMini />
                    </button>
                  ))}
                </div>
                <div className="mt-3 rounded-md bg-muted/50 px-3 py-2 text-[11px] leading-relaxed text-muted-foreground">
                  先看业务影响，再决定执行边界 · 全程留痕
                </div>
              </div>
            </div>
          </>
        )}

        {tab === 'goals' && (
          <>
            {/* S2 · 目标与价值 */}
            <div className="flex items-center justify-between rounded-lg border bg-card px-4 py-3">
              <div>
                <div className="micro-label">GOALS / VALUE</div>
                <div className="mt-0.5 text-[15px] font-semibold">目标与价值</div>
              </div>
              <span className="text-[11px] text-muted-foreground">每项行动，都有一个经营理由 · 目标拆解、指标口径、负责人和验收证据在同一条链路上</span>
            </div>
            <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
              {GOALS.map((g) => (
                <div key={g.tag} className="rounded-lg border bg-card p-4">
                  <div className="flex items-center justify-between">
                    <span className={cn('rounded px-1.5 py-0.5 text-[11px] font-semibold', TAG_STYLE[g.tag])}>{g.tag}</span>
                    <span className="text-[11px] text-muted-foreground">{g.tagLabel}</span>
                  </div>
                  <div className="mt-2.5 text-[14px] font-semibold">{g.title}</div>
                  <div className="text-[10.5px] text-muted-foreground">{g.scope}</div>
                  <div className="tnum mt-2 text-[26px] font-semibold leading-none tracking-tight">
                    {g.value} <span className="text-[13px] font-medium text-muted-foreground">{g.unit}</span>
                  </div>
                  <div className="mt-1.5 text-[11px] text-muted-foreground">{g.target}</div>
                  <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-stone-100">
                    <div className="h-full rounded-full bg-gradient-to-r from-sky-700 to-cyan-500" style={{ width: `${g.progress}%` }} />
                  </div>
                  <div className="mt-1.5 flex justify-between text-[10.5px] text-muted-foreground">
                    <span>达成 {g.progress}%</span>
                    <span>{g.owner}</span>
                  </div>
                  <div className="mt-3 space-y-1.5 border-t pt-3">
                    {g.links.map((l) => (
                      <button
                        key={l.name}
                        onClick={() => setTab('actions')}
                        className="flex w-full items-center justify-between text-[12px] transition-colors hover:text-primary"
                      >
                        <span>{l.name}</span>
                        <span className="tnum mono text-muted-foreground">{l.pct}% ›</span>
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <div className="grid grid-cols-1 gap-3 rounded-lg border bg-card p-4 md:grid-cols-3">
              {VERIFY_RULES.map((r) => (
                <div key={r.no} className="flex gap-3">
                  <span className="tnum mono text-[13px] font-semibold text-primary">{r.no}</span>
                  <div>
                    <div className="text-[12.5px] font-medium">{r.title}</div>
                    <div className="mt-0.5 text-[11.5px] leading-relaxed text-muted-foreground">{r.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {tab === 'actions' && (
          <>
            {/* S4 · 重点行动推进 */}
            <div className="rounded-lg border bg-card">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b px-4 py-3.5">
                <div>
                  <div className="micro-label">ACTIONS / 04</div>
                  <div className="mt-0.5 text-[15px] font-semibold">重点行动推进</div>
                </div>
                <div className="flex items-center gap-1 rounded-md bg-muted/60 p-0.5">
                  {(['全部项目', '需关注', '待验收'] as const).map((f) => (
                    <button
                      key={f}
                      onClick={() => setProjFilter(f)}
                      className={cn('rounded px-2.5 py-1 text-xs transition-colors', projFilter === f ? 'bg-card font-medium shadow-sm' : 'text-muted-foreground hover:text-foreground')}
                    >
                      {f}
                    </button>
                  ))}
                </div>
                <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
                  <span className="hidden md:inline">目标 → 行动 → 交付 → 验收</span>
                  <Button variant="outline" size="sm" onClick={() => go('approvals')}>全部项目 <ArrowRight className="ml-1 size-3.5" /></Button>
                </div>
              </div>
              <table className="w-full text-[13px]">
                <thead>
                  <tr className="border-b bg-muted/40 text-left text-[11px] text-muted-foreground">
                    <th className="px-4 py-2 font-medium">行动项目 / 经营目标</th>
                    <th className="px-3 py-2 font-medium">业务负责人</th>
                    <th className="w-44 px-3 py-2 font-medium">进度</th>
                    <th className="px-3 py-2 text-right font-medium">核验价值</th>
                    <th className="px-4 py-2 text-right font-medium">状态</th>
                  </tr>
                </thead>
                <tbody>
                  {projects.map((p) => (
                    <tr key={p.name} className="border-b transition-colors last:border-0 hover:bg-muted/40">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2.5">
                          <span className="flex size-7 shrink-0 items-center justify-center rounded-md bg-muted text-[12px] font-semibold text-muted-foreground">{p.icon}</span>
                          <div className="min-w-0">
                            <div className="font-medium">{p.name}</div>
                            <div className="text-[11px] text-muted-foreground">{p.goal}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-3 py-3">
                        <div>{p.owner}</div>
                        <div className="text-[11px] text-muted-foreground">{p.org}</div>
                      </td>
                      <td className="px-3 py-3">
                        <div className="flex items-center gap-2">
                          <div className="h-1.5 w-24 overflow-hidden rounded-full bg-stone-100">
                            <div className={cn('h-full rounded-full', p.status === '需关注' ? 'bg-amber-500' : 'bg-sky-700')} style={{ width: `${p.progress}%` }} />
                          </div>
                          <span className="tnum mono text-[11.5px] text-muted-foreground">{p.progress}%</span>
                        </div>
                      </td>
                      <td className="tnum mono px-3 py-3 text-right">{p.value ?? <span className="text-muted-foreground">待核验</span>}</td>
                      <td className="px-4 py-3 text-right">
                        <span className={cn('inline-flex rounded-full px-2 py-0.5 text-[11px] font-medium ring-1 ring-inset', PROJ_STATUS[p.status])}>{p.status}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="flex items-center justify-between px-4 py-2.5 text-[11px] text-muted-foreground">
                <span>仅展示重点行动；集团价值包含其他已验收场景 · 过程按质量门推进，不使用施工人天</span>
                <button className="text-primary hover:underline" onClick={() => toast.info('目标地图', { description: '目标 → 行动 → 交付 → 验收 全链路视图（演示）' })}>查看目标地图 →</button>
              </div>
            </div>

            {/* S5 · 交付任务看板 */}
            <div className="rounded-lg border bg-card p-4">
              <SectionHead
                label="DELIVERY / KANBAN"
                title="交付任务看板"
                extra="点击任务查看执行记录与验收标准 · 有负责人、有边界、有交付标准"
              />
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
                {TASK_KANBAN.map((col) => (
                  <div key={col.col} className="rounded-md bg-muted/40 p-2.5">
                    <div className="mb-2 flex items-center justify-between px-1">
                      <span className="text-[12px] font-medium">{col.col}</span>
                      <span className="tnum mono rounded-full bg-card px-1.5 py-px text-[10.5px] text-muted-foreground">{col.tasks.length}</span>
                    </div>
                    <div className="space-y-2">
                      {col.tasks.map((t) => (
                        <button
                          key={t.title}
                          onClick={() => toast.info(t.title, { description: `执行记录与验收标准（演示）· ${t.worker} · ${t.due}` })}
                          className="w-full rounded-md border bg-card p-2.5 text-left transition-all hover:-translate-y-0.5 hover:shadow-sm"
                        >
                          <span className={cn('rounded px-1 py-px text-[10px] font-semibold', TAG_STYLE[t.tag])}>{t.tag}</span>
                          <div className="mt-1.5 text-[12.5px] font-medium leading-snug">{t.title}</div>
                          <div className="mt-1 text-[10.5px] text-muted-foreground">{t.project}</div>
                          <div className="mt-2 flex items-center justify-between border-t pt-1.5 text-[10.5px] text-muted-foreground">
                            <span>✧ {t.worker}</span>
                            <span className="tnum mono">{t.due}</span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {tab === 'collab' && (
          <>
            {/* S6 · 数字员工与人机协作 */}
            <div>
              <SectionHead
                label="COLLAB / HUMAN × AI"
                title="人机协作"
                extra="人负责判断，数字员工负责交付 · 把对话、任务、资源与结果留在同一个业务上下文里"
                actions={
                  <Button variant="outline" size="sm" onClick={() => toast.info('部门任务', { description: '按部门下钻任务与交付（演示）' })}>
                    查看部门任务 <ArrowRight className="ml-1 size-3.5" />
                  </Button>
                }
              />
              <div className="mb-3 flex flex-wrap gap-2">
                {COLLAB.depts.map((d, i) => (
                  <button
                    key={d}
                    onClick={() => toast.info(`已切换：${d}`, { description: '演示会话为生产运营部视角' })}
                    className={cn(
                      'rounded-full px-3 py-1 text-[12.5px] transition-colors',
                      i === 0 ? 'bg-foreground text-background' : 'bg-card text-muted-foreground ring-1 ring-border hover:text-foreground',
                    )}
                  >
                    {d}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
                {/* 数字员工正在协作 */}
                <div className="rounded-lg border bg-card p-4">
                  <div className="mb-3 flex items-center justify-between">
                    <span className="text-[13.5px] font-semibold">数字员工正在协作</span>
                    <span className="text-[10.5px] text-muted-foreground">3 位</span>
                  </div>
                  <div className="space-y-2">
                    {DIGITAL_WORKERS.map((w) => (
                      <div key={w.name} className="flex items-center gap-3 rounded-md border p-2.5">
                        <span className="flex size-8 shrink-0 items-center justify-center rounded-md bg-muted text-[12px] font-semibold text-muted-foreground">{w.icon}</span>
                        <div className="min-w-0 flex-1">
                          <div className="text-[13px] font-medium">{w.name}</div>
                          <div className="truncate text-[11px] text-muted-foreground">{w.task}</div>
                        </div>
                        <span className="flex shrink-0 items-center gap-1.5 text-[10.5px] text-muted-foreground">
                          <span className={cn('size-[6px] rounded-full', w.statusColor, w.status === '在线' && 'pulse-dot')} /> {w.status}
                        </span>
                      </div>
                    ))}
                  </div>
                  <div className="mt-3 rounded-md bg-muted/50 px-3 py-2 text-[11px] leading-relaxed text-muted-foreground">
                    执行绑定当前部门资源。新增权限与高风险操作先走审批。
                  </div>
                </div>

                {/* 演示会话 */}
                <div className="rounded-lg border bg-card p-4 xl:col-span-2">
                  <div className="mb-3 flex items-center justify-between">
                    <span className="flex items-center gap-2 text-[13.5px] font-semibold">
                      <MessageSquareText className="size-4 text-primary" /> # 生产排程优化
                    </span>
                    <span className="rounded bg-muted px-1.5 py-0.5 text-[10.5px] text-muted-foreground">演示会话</span>
                  </div>
                  <div className="space-y-3">
                    {COLLAB.chat.map((m) => (
                      <div key={m.time} className={cn('flex gap-2.5', m.mine && 'flex-row-reverse')}>
                        <span className={cn(
                          'flex size-7 shrink-0 items-center justify-center rounded-full text-[11px] font-semibold',
                          m.mine ? 'bg-primary/10 text-primary' : 'bg-violet-600/10 text-violet-700',
                        )}>
                          {m.mine ? '李' : '✧'}
                        </span>
                        <div className={cn('max-w-[75%]', m.mine && 'text-right')}>
                          <div className="mb-1 text-[10.5px] text-muted-foreground">{m.who} · {m.time}</div>
                          <div className={cn(
                            'inline-block rounded-lg px-3 py-2 text-[12.5px] leading-relaxed',
                            m.mine ? 'bg-primary text-primary-foreground' : 'bg-muted/70 text-foreground',
                          )}>
                            {m.text}
                          </div>
                          {!m.mine && (
                            <div className="mt-2 rounded-md border bg-card p-3 text-left">
                              <div className="flex items-center gap-1.5 text-[12px] font-medium"><Landmark className="size-3.5 text-primary" />{COLLAB.deliverable.title}</div>
                              <div className="mt-1 text-[11px] text-muted-foreground">依据：{COLLAB.deliverable.basis}</div>
                              <div className="mt-0.5 text-[11px] text-amber-700">{COLLAB.deliverable.status}</div>
                              <button className="mt-1.5 text-[11px] text-primary hover:underline" onClick={() => toast.info('证据与行动', { description: '原始数据快照 / 分析过程 / 验收记录（演示）' })}>
                                查看证据与行动 →
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 flex items-center gap-2 rounded-md border bg-muted/40 px-3 py-2 text-[11.5px] text-muted-foreground">
                    描述目标和交付要求… 例如：生成今天的项目复盘
                    <Send className="ml-auto size-3.5" />
                  </div>
                  <div className="mt-1.5 text-[10.5px] text-muted-foreground">✧ 固定回复演示 · 人工确认后转为任务</div>
                </div>
              </div>

              {/* 当前目标 + 执行边界 */}
              <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2">
                <div className="flex items-center justify-between rounded-lg border bg-card px-4 py-3">
                  <div>
                    <div className="micro-label">当前业务目标</div>
                    <div className="mt-1 text-[13px] font-medium">{COLLAB.goal.title}</div>
                  </div>
                  <div className="tnum text-right">
                    <span className="text-[20px] font-semibold">{COLLAB.goal.current}</span>
                    <span className="ml-2 text-[11px] text-muted-foreground">{COLLAB.goal.target}</span>
                  </div>
                </div>
                <div className="rounded-lg border bg-card px-4 py-3">
                  <div className="micro-label mb-2">执行边界</div>
                  <div className="grid grid-cols-2 gap-x-6 gap-y-1.5 text-[12px] md:grid-cols-4">
                    {COLLAB.boundaries.map(([k, v]) => (
                      <div key={k} className="flex justify-between gap-2"><span className="text-muted-foreground">{k}</span><span>{v}</span></div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </>
        )}

        {tab === 'ops' && (
          <>
            {/* S7 · 平台运行（资源与治理） */}
            <div>
              <SectionHead
                label="PLATFORM / OPS"
                title="平台运行"
                extra="元冰可 AIOS 资源与治理口径 · 用量透明与内部成本穿透"
              />
              <div className="mb-3 grid grid-cols-2 gap-3 xl:grid-cols-4">
                <Stat label="受管 AI 资产" value={ASSETS.length} sub={`已上线 ${online} · 草稿 2 · 弃用 1`} />
                <Stat label="今日调用" value={DAILY_CALLS[27].toLocaleString()} sub="近 7 日环比 +6.8%" />
                <Stat label="今日消耗" value={`${DAILY_TOKENS[27]} 万 tok`} sub="计量管道 schema v1 · 幂等入账" />
                <Stat label="风险" value={crit + warn} tone={crit > 0 ? 'crit' : 'warn'} sub={crit > 0 ? `熔断 ${crit} · 关注 ${warn}` : '无熔断项'} />
              </div>

              <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
                <div className="rounded-lg border bg-card p-4 xl:col-span-2">
                  <SectionHead
                    label="USAGE / 28 DAYS"
                    title="用量趋势"
                    extra="部门 / Agent / Skill 三维聚合"
                    actions={<Button variant="outline" size="sm" onClick={() => go('usage')}>用量报表 <ArrowRight className="ml-1 size-3.5" /></Button>}
                  />
                  <AreaChart series={DAILY_TOKENS} labels={labels} unit="万 tokens / 日" />
                  <div className="mt-2 flex items-center justify-between border-t pt-2.5 text-xs text-muted-foreground">
                    <span>成本参考合计 <span className="tnum mono font-medium text-foreground">¥ {DAILY_COST[27].toLocaleString()}</span> / 日</span>
                    <span className="inline-flex items-center gap-1"><CircleCheck className="size-3.5 text-emerald-600" /> 对账 28/28 天零不符</span>
                  </div>
                </div>
                <div className="rounded-lg border bg-card p-4">
                  <SectionHead label="COST / MIX" title="成本构成" extra="按资产类型 · 内部采购成本参考" />
                  <Donut parts={typeShare} centerLabel="月成本参考" centerValue={`¥${(typeShare.reduce((s, p) => s + p.value, 0) / 10000).toFixed(2)}万`} />
                </div>
              </div>

              <div className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-3">
                <div className="rounded-lg border bg-card p-4">
                  <SectionHead label="BY ORG" title="部门用量" extra="近 30 天 · tokens 占比" />
                  <HBarList items={DEPT_USAGE.map((d) => ({ name: d.org, value: d.tokens }))} format={(v) => `${v.toLocaleString()} 万`} />
                </div>
                <div className="rounded-lg border bg-card p-4">
                  <SectionHead
                    label="TODO / L4"
                    title="待办审批"
                    actions={<Button variant="ghost" size="sm" onClick={() => go('approvals')}>全部 <ArrowRight className="ml-1 size-3.5" /></Button>}
                  />
                  <div className="space-y-2">
                    {APPROVALS.slice(0, 3).map((ap) => (
                      <button
                        key={ap.id}
                        onClick={() => go('approvals')}
                        className="flex w-full items-start gap-3 rounded-md border border-transparent p-2 text-left transition-colors hover:border-border hover:bg-muted/50"
                      >
                        <span className={cn('mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-md',
                          ap.risk === '安全加签' ? 'bg-red-600/10 text-red-700' : ap.risk === '高风险' ? 'bg-amber-500/10 text-amber-700' : 'bg-sky-600/10 text-sky-700')}>
                          <FileCheck2 className="size-3.5" />
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-[13px] font-medium">{ap.title}</span>
                          <span className="mt-0.5 block text-[11px] text-muted-foreground">{ap.applicant} · <span className="mono">{ap.id}</span></span>
                        </span>
                        <span className={cn('shrink-0 rounded-full px-1.5 py-0.5 text-[10px] ring-1 ring-inset',
                          ap.risk === '安全加签' ? 'text-red-700 ring-red-600/30' : ap.risk === '高风险' ? 'text-amber-700 ring-amber-500/40' : 'text-stone-500 ring-stone-400/40')}>{ap.risk}</span>
                      </button>
                    ))}
                  </div>
                </div>
                <div className="rounded-lg border bg-card p-4">
                  <SectionHead
                    label="LIVE / EVENTS" title="事件流"
                    extra={<span className="inline-flex items-center gap-1.5 text-xs text-emerald-700"><Radio className="size-3.5" /> SSE 实时推送</span>}
                    actions={<Button variant="ghost" size="sm" onClick={() => go('audit')}>审计 <ArrowRight className="ml-1 size-3.5" /></Button>}
                  />
                  <div className="relative space-y-0 pl-1">
                    {AUDIT_LOGS.slice(0, 5).map((log, i) => (
                      <div key={log.id} className="relative flex gap-3 pb-3.5 last:pb-0">
                        {i < 4 && <span className="absolute left-[5px] top-3.5 h-full w-px bg-border" />}
                        <span className={cn('relative mt-1.5 size-[11px] shrink-0 rounded-full ring-4 ring-card',
                          log.result === 'alert' ? 'bg-red-500' : log.result === 'deny' ? 'bg-amber-500' : 'bg-emerald-500')} />
                        <div className="min-w-0">
                          <div className="truncate text-[13px]">{log.action}</div>
                          <div className="tnum mono mt-0.5 text-[11px] text-muted-foreground">{log.time} · {log.actor}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* S8 · 资产健康速览 */}
            <div className="rounded-lg border bg-card p-4">
              <SectionHead
                label="FLEET / HEALTH" title="资产健康速览"
                actions={
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => toast.success('健康巡检完成', { description: '20 项资产批量探活已留痕 audit：ops.fleet.inspect' })}>
                      <Zap className="mr-1 size-3.5" /> 一键巡检
                    </Button>
                    <Button size="sm" onClick={() => go('assets')}>资产台账 <ArrowRight className="ml-1 size-3.5" /></Button>
                  </div>
                }
              />
              <div className="grid grid-cols-2 gap-2 md:grid-cols-4 xl:grid-cols-5">
                {ASSETS.filter((a) => a.lifecycle === 'online').slice(0, 10).map((a) => (
                  <button
                    key={a.id}
                    onClick={() => go('assets', a.id)}
                    className="group rounded-md border p-3 text-left transition-colors hover:border-primary/40 hover:bg-muted/40"
                  >
                    <div className="flex items-center justify-between">
                      <span className="rounded bg-muted px-1.5 py-0.5 text-[10.5px] font-semibold text-muted-foreground">{ASSET_TYPE_LABEL[a.type]}</span>
                      <span className={cn('size-[7px] rounded-full',
                        a.health === 'healthy' ? 'bg-emerald-600' : a.health === 'warning' ? 'bg-amber-500' : a.health === 'critical' ? 'bg-red-600 pulse-dot' : 'bg-stone-400')}
                        style={a.health === 'critical' ? { ['--dot-color' as string]: '4 72% 51%' } : undefined} />
                    </div>
                    <div className="mt-2 truncate text-[13px] font-medium">{a.name}</div>
                    <div className="tnum mono mt-0.5 truncate text-[11px] text-muted-foreground">{a.key}</div>
                  </button>
                ))}
              </div>
              {crit > 0 && (
                <div className="mt-3 flex items-center gap-2 rounded-md border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
                  <ShieldAlert className="size-3.5" />
                  mcp:equipment-iot 熔断中，已影响 agent:equipment-check（成功率 91.2%），建议优先处理。
                  <Bot className="ml-auto size-3.5" />
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function ChevronRightMini() {
  return <span className="shrink-0 text-muted-foreground">›</span>;
}
