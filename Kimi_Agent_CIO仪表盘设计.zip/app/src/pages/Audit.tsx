import { useMemo, useState } from 'react';
import { ShieldAlert, Search } from 'lucide-react';
import { AUDIT_LOGS } from '@/data/mock';
import type { AuditLog } from '@/data/mock';
import { SectionHead } from '@/components/shared';
import { cn } from '@/lib/utils';

const TYPES: { v: 'all' | AuditLog['type']; label: string }[] = [
  { v: 'all', label: '全部' },
  { v: 'auth', label: '认证' },
  { v: 'invoke', label: '调用' },
  { v: 'change', label: '变更' },
  { v: 'security', label: '安全' },
];

const RESULT_STYLE = {
  ok: 'text-emerald-700 bg-emerald-600/10',
  deny: 'text-amber-700 bg-amber-500/10',
  alert: 'text-red-700 bg-red-600/10',
};
const RESULT_LABEL = { ok: 'OK', deny: 'DENY', alert: 'ALERT' };

export default function Audit() {
  const [type, setType] = useState<'all' | AuditLog['type']>('all');
  const [q, setQ] = useState('');
  const rows = useMemo(
    () => AUDIT_LOGS.filter((l) => (type === 'all' || l.type === type) && (!q || l.action.includes(q) || l.actor.includes(q) || l.target.includes(q))),
    [type, q],
  );

  return (
    <div className="space-y-4">
      <SectionHead
        label="AUDIT / ALERT"
        title="审计与告警"
        extra="四类审计日志 · act 链可还原完整调用链路 · 越权计数自动告警"
      />

      {/* 告警规则速览 */}
      <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
        {[
          { name: '连续登录失败 ≥ 5 次 / 15 分钟', fired: 1, level: 'critical', desc: '今日 10:31 触发 · 外部 IP 已锁定' },
          { name: '计量 run/meter 对账不符', fired: 0, level: 'ok', desc: '28 天交叉校验零不符' },
          { name: '弃用 Skill 仍被引用', fired: 3, level: 'warning', desc: 'skill:dingtalk-flow · 待迁移 Agent 3 个' },
        ].map((r) => (
          <div key={r.name} className={cn('rounded-lg border bg-card p-3.5', r.level === 'critical' && 'border-red-200 bg-red-50/50')}>
            <div className="flex items-center justify-between">
              <span className="text-[13px] font-medium">{r.name}</span>
              {r.level === 'critical' && <ShieldAlert className="size-4 text-red-600" />}
            </div>
            <div className="tnum mt-1.5 text-[20px] font-semibold">{r.fired} <span className="text-xs font-normal text-muted-foreground">次触发（24h）</span></div>
            <div className="mt-1 text-[11.5px] text-muted-foreground">{r.desc}</div>
          </div>
        ))}
      </div>

      {/* 过滤器 */}
      <div className="flex flex-wrap items-center gap-2">
        {TYPES.map((t) => (
          <button
            key={t.v}
            onClick={() => setType(t.v)}
            className={cn(
              'rounded-full px-3 py-1 text-[12.5px] transition-colors',
              type === t.v ? 'bg-foreground text-background' : 'bg-card text-muted-foreground ring-1 ring-border hover:text-foreground',
            )}
          >
            {t.label}
          </button>
        ))}
        <div className="relative ml-auto">
          <Search className="absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="搜索动作 / 主体 / 目标"
            className="h-8 w-52 rounded-md border bg-card pl-8 pr-3 text-[12.5px] outline-none ring-primary/30 placeholder:text-muted-foreground/70 focus:ring-2"
          />
        </div>
      </div>

      {/* 日志表 */}
      <div className="overflow-hidden rounded-lg border bg-card">
        <table className="w-full text-[13px]">
          <thead>
            <tr className="border-b bg-muted/40 text-left text-[11px] text-muted-foreground">
              <th className="px-4 py-2.5 font-medium">时间</th>
              <th className="px-3 py-2.5 font-medium">类型</th>
              <th className="px-3 py-2.5 font-medium">动作</th>
              <th className="px-3 py-2.5 font-medium">调用链（act）</th>
              <th className="px-3 py-2.5 font-medium">目标</th>
              <th className="px-4 py-2.5 text-right font-medium">结果</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((l) => (
              <tr key={l.id} className="border-b transition-colors last:border-0 hover:bg-muted/40">
                <td className="tnum mono whitespace-nowrap px-4 py-3 text-[12px] text-muted-foreground">{l.time}</td>
                <td className="px-3 py-3">
                  <span className="rounded bg-muted px-1.5 py-0.5 text-[11px]">{{ auth: '认证', invoke: '调用', change: '变更', security: '安全' }[l.type]}</span>
                </td>
                <td className="max-w-[220px] truncate px-3 py-3">{l.action}</td>
                <td className="px-3 py-3">
                  <div className="flex max-w-[300px] flex-wrap items-center gap-1">
                    {l.actChain.map((c, i) => (
                      <span key={i} className="flex items-center gap-1">
                        <span className="mono whitespace-nowrap rounded bg-muted px-1.5 py-0.5 text-[10.5px]">{c}</span>
                        {i < l.actChain.length - 1 && <span className="text-muted-foreground">→</span>}
                      </span>
                    ))}
                  </div>
                </td>
                <td className="mono px-3 py-3 text-[12px] text-muted-foreground">{l.target}</td>
                <td className="px-4 py-3 text-right">
                  <span className={cn('rounded-full px-2 py-0.5 text-[10.5px] font-semibold', RESULT_STYLE[l.result])}>
                    {RESULT_LABEL[l.result]}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-[11px] text-muted-foreground">
        事件锚点 + 场景维度时间线已留存 · 人类控制台读操作不产生日志（噪音控制）· 机器身份读台账入审计（agent.verify）
      </p>
    </div>
  );
}
