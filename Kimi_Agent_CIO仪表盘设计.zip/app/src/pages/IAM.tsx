import { Users, RefreshCw, Building2, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';
import { IAM_USERS, ORGS, PLATFORM_CONN } from '@/data/mock';
import { SectionHead } from '@/components/shared';
import { Button } from '@/components/ui/button';

export default function IAM() {
  return (
    <div className="space-y-4">
      <SectionHead
        label="IAM / ORG"
        title="组织与账号"
        extra="一套身份贯穿 MCP / Agent / 应用 / Skill / 模型 / NAS · 钉钉连接器定时自动同步（30 分钟）"
        actions={
          <Button size="sm" variant="outline" onClick={() => toast.success('手动同步完成', { description: '1,023 人 / 42 部门 · 0 冲突 · actor: 手动' })}>
            <RefreshCw className="mr-1 size-3.5" /> 立即同步
          </Button>
        }
      />

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        {/* 组织树 */}
        <div className="rounded-lg border bg-card p-4">
          <SectionHead label="ORG TREE" title="组织结构" />
          <div className="space-y-1">
            <div className="flex items-center gap-2 rounded-md bg-muted/60 px-3 py-2 text-[13px] font-medium">
              <Building2 className="size-3.5 text-primary" /> 华辰精密制造集团
            </div>
            {ORGS.map((o, i) => (
              <div key={o.id} className="relative flex items-center gap-2 py-1.5 pl-3">
                <span className="absolute left-0 top-0 h-full w-px bg-border" style={{ display: i === 0 ? 'none' : undefined }} />
                <span className="absolute left-0 top-1/2 h-px w-3 bg-border" />
                <div className="flex w-full items-center justify-between rounded-md px-2 py-1 text-[13px] hover:bg-muted/50">
                  <span>{o.name}</span>
                  <span className="tnum mono text-[11px] text-muted-foreground">{o.members} 人</span>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 border-t pt-3.5">
            <div className="micro-label mb-2">三方连接器</div>
            <div className="rounded-md border p-3">
              <div className="flex items-center justify-between">
                <span className="text-[13px] font-medium">{PLATFORM_CONN.connector.name}</span>
                <span className="flex items-center gap-1.5 text-[11px] text-emerald-700">
                  <span className="size-[6px] rounded-full bg-emerald-600 pulse-dot" /> 已启用
                </span>
              </div>
              <div className="mt-1.5 space-y-1 text-[11.5px] text-muted-foreground">
                <div className="flex justify-between"><span>模式</span><span className="mono">{PLATFORM_CONN.connector.mode}</span></div>
                <div className="flex justify-between"><span>同步频率</span><span className="mono">每 {PLATFORM_CONN.connector.intervalMinutes} 分钟</span></div>
                <div className="flex justify-between"><span>最近同步</span><span className="mono">{PLATFORM_CONN.connector.lastSync} · 0 冲突</span></div>
              </div>
            </div>
          </div>
        </div>

        {/* 账号表 */}
        <div className="rounded-lg border bg-card xl:col-span-2">
          <div className="border-b px-4 py-3">
            <span className="text-[14px] font-semibold">账号</span>
            <span className="tnum ml-2 text-xs text-muted-foreground">1,023 在职 · 演示视角展示关键岗位</span>
          </div>
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b bg-muted/40 text-left text-[11px] text-muted-foreground">
                <th className="px-4 py-2.5 font-medium">成员</th>
                <th className="px-3 py-2.5 font-medium">账号</th>
                <th className="px-3 py-2.5 font-medium">角色</th>
                <th className="px-3 py-2.5 font-medium">组织</th>
                <th className="px-4 py-2.5 text-right font-medium">MFA</th>
              </tr>
            </thead>
            <tbody>
              {IAM_USERS.map((u) => (
                <tr key={u.account} className="border-b transition-colors last:border-0 hover:bg-muted/40">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      <span className="flex size-7 items-center justify-center rounded-full bg-primary/10 text-[11px] font-semibold text-primary">
                        {u.name.slice(0, 1)}
                      </span>
                      <span className="font-medium">{u.name}</span>
                    </div>
                  </td>
                  <td className="mono px-3 py-3 text-[12px] text-muted-foreground">{u.account}</td>
                  <td className="px-3 py-3"><span className="rounded bg-muted px-1.5 py-0.5 text-[11px]">{u.role}</span></td>
                  <td className="max-w-[200px] truncate px-3 py-3 text-muted-foreground">{u.org}</td>
                  <td className="px-4 py-3 text-right">
                    {u.mfa ? (
                      <span className="inline-flex items-center gap-1 text-[11px] text-emerald-700"><ShieldCheck className="size-3.5" /> 已开启</span>
                    ) : (
                      <span className="text-[11px] text-amber-700">未开启</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          ['权限点矩阵', '角色 × 权限点统一注册，越权即拒绝'],
          ['动态用户组', 'C 叠加组按组织链自动重算，漂移即告警'],
          ['一人一号', '引擎级唯一约束兜底，冲突走对比式工单'],
          ['冻结联动', '冻结即吊销全部令牌（含 refresh 链）'],
        ].map(([t1, d]) => (
          <div key={t1} className="rounded-lg border bg-card p-3.5">
            <div className="flex items-center gap-1.5 text-[13px] font-medium"><Users className="size-3.5 text-primary" />{t1}</div>
            <div className="mt-1 text-[11.5px] leading-relaxed text-muted-foreground">{d}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
