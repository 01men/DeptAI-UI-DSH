import type { ReactNode } from 'react';
import { cn } from '@/lib/utils';
import type { Health, Lifecycle, AssetType } from '@/data/mock';
import {
  HEALTH_LABEL, LIFECYCLE_LABEL, ASSET_TYPE_LABEL,
} from '@/data/mock';

// ---------- 健康红绿灯 ----------
const HEALTH_STYLE: Record<Health, string> = {
  healthy: 'bg-emerald-600',
  warning: 'bg-amber-500',
  critical: 'bg-red-600',
  offline: 'bg-stone-400',
};

export function HealthDot({ health, pulse }: { health: Health; pulse?: boolean }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span
        className={cn('inline-block size-[7px] rounded-full', HEALTH_STYLE[health], pulse && health === 'critical' && 'pulse-dot')}
        style={health === 'critical' ? { ['--dot-color' as string]: '4 72% 51%' } : undefined}
      />
      <span className="text-xs text-muted-foreground">{HEALTH_LABEL[health]}</span>
    </span>
  );
}

// ---------- 生命周期徽章 ----------
const LIFECYCLE_STYLE: Record<Lifecycle, string> = {
  online: 'text-emerald-700 bg-emerald-600/10 ring-emerald-600/20',
  draft: 'text-sky-700 bg-sky-600/10 ring-sky-600/20',
  offline: 'text-stone-500 bg-stone-500/10 ring-stone-500/20',
  archived: 'text-stone-500 bg-stone-500/10 ring-stone-500/20',
  deprecated: 'text-amber-700 bg-amber-500/10 ring-amber-500/25',
};

export function LifecycleBadge({ s }: { s: Lifecycle }) {
  return (
    <span className={cn('inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium ring-1 ring-inset', LIFECYCLE_STYLE[s])}>
      {LIFECYCLE_LABEL[s]}
    </span>
  );
}

// ---------- 资产类型徽章 ----------
const TYPE_STYLE: Record<AssetType, string> = {
  mcp: 'text-cyan-700 bg-cyan-600/10',
  agent: 'text-violet-700 bg-violet-600/10',
  app: 'text-blue-700 bg-blue-600/10',
  skill: 'text-emerald-700 bg-emerald-600/10',
  model: 'text-amber-700 bg-amber-500/10',
  nas: 'text-rose-700 bg-rose-500/10',
};

export function TypeBadge({ type }: { type: AssetType }) {
  return (
    <span className={cn('inline-flex items-center rounded px-1.5 py-0.5 text-[11px] font-semibold', TYPE_STYLE[type])}>
      {ASSET_TYPE_LABEL[type]}
    </span>
  );
}

// ---------- 区块标题 ----------
export function SectionHead({
  label, title, extra, actions,
}: { label?: string; title: ReactNode; extra?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
      <div>
        {label && <div className="micro-label mb-1">{label}</div>}
        <h2 className="text-[17px] font-semibold tracking-tight text-foreground">{title}</h2>
        {extra && <div className="mt-0.5 text-xs text-muted-foreground">{extra}</div>}
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}

// ---------- 灰度进度条 ----------
export function GrayProgress({ percent }: { percent: number }) {
  return (
    <div className="flex items-center gap-2">
      <div className="h-1.5 w-20 overflow-hidden rounded-full bg-stone-200">
        <div className="h-full rounded-full bg-gradient-to-r from-sky-500 to-cyan-400" style={{ width: `${percent}%` }} />
      </div>
      <span className="tnum mono text-[11px] text-muted-foreground">灰度 {percent}%</span>
    </div>
  );
}

// ---------- 趋势折线（纯 SVG） ----------
export function Sparkline({ data, className, stroke = 'hsl(201 88% 31%)' }: { data: number[]; className?: string; stroke?: string }) {
  const w = 120, h = 30, max = Math.max(...data, 1), min = Math.min(...data, 0);
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - 3 - ((v - min) / (max - min || 1)) * (h - 6)}`);
  const d = `M${pts.join(' L')}`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className={cn('h-[30px] w-[120px]', className)} preserveAspectRatio="none" aria-hidden>
      <path d={`${d} L${w},${h} L0,${h} Z`} fill={stroke} opacity="0.08" />
      <path d={d} fill="none" stroke={stroke} strokeWidth="1.6" strokeLinejoin="round" />
    </svg>
  );
}

// ---------- 面积趋势图（带坐标轴） ----------
export function AreaChart({
  series, labels, height = 180, color = 'hsl(201 88% 31%)', unit,
}: { series: number[]; labels: string[]; height?: number; color?: string; unit?: string }) {
  const w = 720, h = height, padL = 42, padB = 22, padT = 10;
  const max = Math.max(...series) * 1.12;
  const x = (i: number) => padL + (i / (series.length - 1)) * (w - padL - 8);
  const y = (v: number) => padT + (1 - v / max) * (h - padT - padB);
  const d = series.map((v, i) => `${i === 0 ? 'M' : 'L'}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' ');
  const area = `${d} L${x(series.length - 1)},${h - padB} L${x(0)},${h - padB} Z`;
  const ticks = 4;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full" role="img" aria-label="趋势图">
      <defs>
        <linearGradient id="ag" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.16" />
          <stop offset="100%" stopColor={color} stopOpacity="0.01" />
        </linearGradient>
      </defs>
      {Array.from({ length: ticks + 1 }, (_, i) => {
        const v = (max / ticks) * i;
        return (
          <g key={i}>
            <line x1={padL} x2={w - 8} y1={y(v)} y2={y(v)} stroke="hsl(40 9% 88%)" strokeWidth="1" strokeDasharray={i === 0 ? '' : '2 4'} />
            <text x={padL - 6} y={y(v) + 3.5} textAnchor="end" className="fill-muted-foreground" fontSize="9.5">
              {Math.round(v)}
            </text>
          </g>
        );
      })}
      <path d={area} fill="url(#ag)" />
      <path d={d} fill="none" stroke={color} strokeWidth="1.8" strokeLinejoin="round" />
      {series.map((v, i) => (
        <circle key={i} cx={x(i)} cy={y(v)} r={i === series.length - 1 ? 3 : 0} fill={color} stroke="white" strokeWidth="1.5" />
      ))}
      {labels.map((l, i) =>
        i % Math.ceil(labels.length / 7) === 0 ? (
          <text key={i} x={x(i)} y={h - 6} textAnchor="middle" className="fill-muted-foreground" fontSize="9.5">{l}</text>
        ) : null,
      )}
      {unit && <text x={w - 8} y={12} textAnchor="end" className="fill-muted-foreground" fontSize="9.5">{unit}</text>}
    </svg>
  );
}

// ---------- 双序列趋势（实线 + 虚线目标） ----------
export function DualTrendChart({
  actual, target, labels, height = 200, unit, color = 'hsl(201 88% 31%)',
}: { actual: number[]; target: number[]; labels: string[]; height?: number; unit?: string; color?: string }) {
  const w = 720, h = height, padL = 40, padB = 22, padT = 12;
  const max = Math.max(...target, ...actual) * 1.15;
  const x = (i: number) => padL + (i / (actual.length - 1)) * (w - padL - 10);
  const y = (v: number) => padT + (1 - v / max) * (h - padT - padB);
  const path = (arr: number[]) => arr.map((v, i) => `${i === 0 ? 'M' : 'L'}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' ');
  const ticks = 4;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full" role="img" aria-label="价值兑现趋势">
      <defs>
        <linearGradient id="dg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.14" />
          <stop offset="100%" stopColor={color} stopOpacity="0.01" />
        </linearGradient>
      </defs>
      {Array.from({ length: ticks + 1 }, (_, i) => {
        const v = (max / ticks) * i;
        return (
          <g key={i}>
            <line x1={padL} x2={w - 10} y1={y(v)} y2={y(v)} stroke="hsl(40 9% 88%)" strokeWidth="1" strokeDasharray={i === 0 ? '' : '2 4'} />
            <text x={padL - 6} y={y(v) + 3.5} textAnchor="end" className="fill-muted-foreground" fontSize="9.5">{Math.round(v)}</text>
          </g>
        );
      })}
      <path d={`${path(actual)} L${x(actual.length - 1)},${h - padB} L${x(0)},${h - padB} Z`} fill="url(#dg)" />
      <path d={path(target)} fill="none" stroke="hsl(30 4% 55%)" strokeWidth="1.4" strokeDasharray="5 4" />
      <path d={path(actual)} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" />
      <circle cx={x(actual.length - 1)} cy={y(actual[actual.length - 1])} r="3.2" fill={color} stroke="white" strokeWidth="1.5" />
      {labels.map((l, i) =>
        i % 2 === 0 ? (
          <text key={i} x={x(i)} y={h - 6} textAnchor="middle" className="fill-muted-foreground" fontSize="9.5">{l}</text>
        ) : null,
      )}
      {unit && <text x={w - 10} y={13} textAnchor="end" className="fill-muted-foreground" fontSize="9.5">{unit}</text>}
    </svg>
  );
}

// ---------- 横向条形排行 ----------
export function HBarList({
  items, format,
}: { items: { name: string; value: number; hint?: string }[]; format?: (v: number) => string }) {
  const max = Math.max(...items.map((i) => i.value), 1);
  return (
    <div className="space-y-2.5">
      {items.map((it, idx) => (
        <div key={it.name} className="group">
          <div className="mb-1 flex items-baseline justify-between gap-3">
            <span className="truncate text-[13px] text-foreground">
              <span className="tnum mono mr-2 text-[11px] text-muted-foreground">{String(idx + 1).padStart(2, '0')}</span>
              {it.name}
            </span>
            <span className="tnum mono whitespace-nowrap text-[12px] text-foreground">{format ? format(it.value) : it.value}</span>
          </div>
          <div className="h-[5px] overflow-hidden rounded-full bg-stone-100">
            <div
              className="h-full rounded-full bg-gradient-to-r from-sky-700 to-cyan-500 transition-all group-hover:from-sky-600"
              style={{ width: `${(it.value / max) * 100}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

// ---------- 甜甜圈 ----------
export function Donut({
  parts, size = 120, centerLabel, centerValue,
}: {
  parts: { label: string; value: number; color: string }[];
  size?: number; centerLabel: string; centerValue: string;
}) {
  const total = parts.reduce((s, p) => s + p.value, 0) || 1;
  const r = 44, c = 2 * Math.PI * r;
  let acc = 0;
  return (
    <div className="flex items-center gap-5">
      <div className="relative shrink-0" style={{ width: size, height: size }}>
        <svg viewBox="0 0 120 120" width={size} height={size} className="-rotate-90">
          <circle cx="60" cy="60" r={r} fill="none" stroke="hsl(45 10% 93%)" strokeWidth="13" />
          {parts.map((p, i) => {
            const frac = p.value / total;
            const el = (
              <circle
                key={i} cx="60" cy="60" r={r} fill="none" stroke={p.color} strokeWidth="13"
                strokeDasharray={`${(frac * c).toFixed(2)} ${c.toFixed(2)}`}
                strokeDashoffset={(-acc * c).toFixed(2)} strokeLinecap="butt"
              />
            );
            acc += frac;
            return el;
          })}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="tnum text-lg font-semibold leading-tight">{centerValue}</div>
          <div className="text-[10.5px] text-muted-foreground">{centerLabel}</div>
        </div>
      </div>
      <div className="min-w-0 flex-1 space-y-1.5">
        {parts.map((p, i) => (
          <div key={i} className="flex items-center gap-2 text-xs">
            <span className="size-2 shrink-0 rounded-sm" style={{ background: p.color }} />
            <span className="flex-1 truncate text-muted-foreground">{p.label}</span>
            <span className="tnum mono">{((p.value / total) * 100).toFixed(1)}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------- 空状态 ----------
export function EmptyState({ text, action }: { text: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-lg border border-dashed py-10 text-center">
      <svg width="44" height="44" viewBox="0 0 44 44" fill="none" className="mb-3 text-stone-300">
        <rect x="6" y="10" width="32" height="24" rx="3" stroke="currentColor" strokeWidth="1.5" />
        <path d="M6 18h32" stroke="currentColor" strokeWidth="1.5" />
        <circle cx="12" cy="14" r="1.2" fill="currentColor" />
        <circle cx="16" cy="14" r="1.2" fill="currentColor" />
      </svg>
      <p className="mb-3 text-[13px] text-muted-foreground">{text}</p>
      {action}
    </div>
  );
}

// ---------- 指标卡 ----------
export function Stat({
  label, value, sub, children, tone = 'default',
}: { label: string; value: ReactNode; sub?: ReactNode; children?: ReactNode; tone?: 'default' | 'warn' | 'crit' }) {
  return (
    <div className="rounded-lg border bg-card p-4">
      <div className="micro-label">{label}</div>
      <div
        className={cn(
          'tnum mt-1.5 text-[22px] font-semibold leading-none tracking-tight',
          tone === 'warn' && 'text-amber-600',
          tone === 'crit' && 'text-red-600',
        )}
      >
        {value}
      </div>
      {sub && <div className="mt-1.5 text-xs text-muted-foreground">{sub}</div>}
      {children}
    </div>
  );
}
