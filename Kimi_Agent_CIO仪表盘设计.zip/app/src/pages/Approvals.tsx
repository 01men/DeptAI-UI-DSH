import { useState } from 'react';
import { Check, X, FlaskConical, FileCheck2 } from 'lucide-react';
import { toast } from 'sonner';
import { APPROVALS } from '@/data/mock';
import type { Approval } from '@/data/mock';
import { SectionHead } from '@/components/shared';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const RISK_STYLE: Record<Approval['risk'], string> = {
  安全加签: 'border-red-200 bg-red-50 text-red-700',
  高风险: 'border-amber-200 bg-amber-50 text-amber-700',
  常规: 'border-stone-200 bg-stone-100 text-stone-600',
};

export default function Approvals() {
  const [activeId, setActiveId] = useState(APPROVALS[0].id);
  const [decided, setDecided] = useState<Record<string, 'approved' | 'rejected'>>({});
  const ap = APPROVALS.find((a) => a.id === activeId)!;
  const state = decided[ap.id];

  const decide = (d: 'approved' | 'rejected') => {
    setDecided((s) => ({ ...s, [ap.id]: d }));
    toast.success(d === 'approved' ? '已通过' : '已驳回', {
      description: `${ap.id} · ${d === 'approved' ? '执行器将自动完成后续动作，结果回写时间线' : '原因已必填留痕，申请人将收到通知'}`,
    });
  };

  return (
    <div>
      <SectionHead
        label="APPROVAL / L4"
        title="审批中心"
        extra="上线 / 下线 / 下架 / 吊销强制审批单 · 有审批权限者单人通过即执行 · 执行结果回写"
      />
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-5">
        {/* 左：申请列表 */}
        <div className="space-y-2 lg:col-span-2">
          {APPROVALS.map((a) => {
            const st = decided[a.id];
            return (
              <button
                key={a.id}
                onClick={() => setActiveId(a.id)}
                className={cn(
                  'fade-up w-full rounded-lg border bg-card p-3.5 text-left transition-all',
                  activeId === a.id ? 'border-primary/50 shadow-[0_4px_16px_-8px_hsl(201_88%_31%/0.4)]' : 'hover:border-primary/30',
                )}
              >
                <div className="flex items-start justify-between gap-2">
                  <span className="text-[13.5px] font-medium leading-snug">{a.title}</span>
                  <span className={cn('shrink-0 rounded-full border px-2 py-0.5 text-[10.5px] font-medium', RISK_STYLE[a.risk])}>{a.risk}</span>
                </div>
                <div className="mt-1.5 flex items-center gap-2 text-[11.5px] text-muted-foreground">
                  <span>{a.applicant}</span>·<span>{a.org}</span>·<span className="mono">{a.submittedAt}</span>
                  {st && (
                    <span className={cn('ml-auto rounded-full px-1.5 py-0.5 text-[10px] font-semibold', st === 'approved' ? 'bg-emerald-600/10 text-emerald-700' : 'bg-red-600/10 text-red-700')}>
                      {st === 'approved' ? '已通过' : '已驳回'}
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* 右：详情 */}
        <div className="rounded-lg border bg-card lg:col-span-3">
          <div className="border-b px-5 py-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-[15px] font-semibold">{ap.title}</div>
                <div className="mt-1 text-xs text-muted-foreground">
                  <span className="mono">{ap.id}</span> · {ap.category} · {ap.applicant} 提交于 {ap.submittedAt}
                </div>
              </div>
              <span className={cn('shrink-0 rounded-full border px-2 py-0.5 text-[10.5px] font-medium', RISK_STYLE[ap.risk])}>{ap.risk}</span>
            </div>
            <p className="mt-3 rounded-md bg-muted/50 p-3 text-[13px] leading-relaxed text-muted-foreground">{ap.reason}</p>
          </div>

          <div className="px-5 py-4">
            <div className="micro-label mb-2 flex items-center gap-1.5"><FlaskConical className="size-3" /> dry-run 影响面预览（已通过）</div>
            <ul className="space-y-1.5">
              {ap.impact.map((im) => (
                <li key={im} className="flex items-start gap-2 text-[13px]">
                  <span className="mt-[7px] size-1 shrink-0 rounded-full bg-primary" />
                  <span className="mono text-[12px] leading-relaxed">{im}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="border-t px-5 py-4">
            <div className="micro-label mb-3">审批时间线</div>
            <div className="space-y-0">
              {ap.timeline.map((t, i) => (
                <div key={i} className="relative flex gap-3 pb-4 last:pb-0">
                  {i < ap.timeline.length - 1 && <span className={cn('absolute left-[9px] top-5 h-full w-px', t.done ? 'bg-emerald-500' : 'bg-border')} />}
                  <span className={cn(
                    'relative mt-0.5 flex size-[19px] shrink-0 items-center justify-center rounded-full text-[10px]',
                    t.done ? 'bg-emerald-600 text-white' : i === ap.timeline.findIndex((x) => !x.done) ? 'bg-primary text-white' : 'bg-muted text-muted-foreground',
                  )}>
                    {t.done ? '✓' : <FileCheck2 className="size-2.5" />}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="text-[13px]">{t.action}</div>
                    <div className="tnum mono mt-0.5 text-[11px] text-muted-foreground">{t.time} · {t.actor}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2 border-t bg-muted/30 px-5 py-3.5">
            {state ? (
              <span className={cn('text-[13px] font-medium', state === 'approved' ? 'text-emerald-700' : 'text-red-700')}>
                本单已{state === 'approved' ? '通过' : '驳回'} · 结果已回写并通知申请人
              </span>
            ) : (
              <>
                <Button size="sm" onClick={() => decide('approved')}><Check className="mr-1 size-3.5" /> 通过并执行</Button>
                <Button size="sm" variant="outline" onClick={() => decide('rejected')}><X className="mr-1 size-3.5" /> 驳回（原因必填）</Button>
                <span className="ml-auto text-[11px] text-muted-foreground">执行期复核 · 挂单期间资源被禁用将执行失败留痕</span>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
