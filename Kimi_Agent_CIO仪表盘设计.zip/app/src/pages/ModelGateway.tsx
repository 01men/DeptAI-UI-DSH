import { Route, Flame, ArrowDown, CircleAlert, Zap } from 'lucide-react';
import { toast } from 'sonner';
import { MODEL_ROUTES as R } from '@/data/mock';
import { SectionHead, Stat } from '@/components/shared';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const CH_STATE: Record<string, { dot: string; label: string; cls: string }> = {
  active: { dot: 'bg-emerald-600', label: '承接流量', cls: 'border-emerald-300 bg-emerald-50/60' },
  degraded: { dot: 'bg-amber-500', label: '降级中', cls: 'border-amber-300 bg-amber-50/60' },
  standby: { dot: 'bg-stone-400', label: '待机', cls: 'border-border bg-muted/30' },
};
const KIND_STYLE: Record<string, string> = { 主力: 'text-red-700 bg-red-600/10', 备用: 'text-amber-700 bg-amber-500/10', 兜底: 'text-stone-500 bg-stone-500/10' };

export default function ModelGateway() {
  const totalTokens = R.reduce((s, r) => s + r.tokens30d, 0);
  return (
    <div className="space-y-4">
      <SectionHead
        label="MODEL GATEWAY"
        title="模型接入网关"
        extra="OpenAI 兼容真实转发 · 实测 tokens 零价快照计量 · 无 endpoint 拒绝调用（不生成假 completion）"
        actions={
          <Button variant="outline" size="sm" onClick={() => toast.success('路由探测完成', { description: '3 条路由 · 7 个渠道全部可达，探测留痕 audit' })}>
            <Zap className="mr-1 size-3.5" /> 渠道探测
          </Button>
        }
      />

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="30d 总消耗" value={`${totalTokens.toLocaleString()} 万`} sub="实测 input/output tokens" />
        <Stat label="路由数" value={R.length} sub={`渠道共 ${R.reduce((s, r) => s + r.channels.length, 0)} 个`} />
        <Stat label="降级事件（30d）" value={3} tone="warn" sub="视觉路由限流 · 自动切换备用" />
        <Stat label="熔断保护" value="80% 预算" sub="超限即熔断并告警" />
      </div>

      <div className="space-y-3">
        {R.map((r) => (
          <div key={r.id} className="rounded-lg border bg-card p-4">
            <div className="flex flex-wrap items-center gap-3">
              <Route className={cn('size-4', r.status === 'healthy' ? 'text-emerald-600' : 'text-amber-600')} />
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-[14.5px] font-semibold">{r.name}</span>
                  <span className="mono rounded bg-muted px-1.5 py-0.5 text-[11px]">{r.model}</span>
                  {r.status === 'warning' && (
                    <span className="flex items-center gap-1 rounded-full bg-amber-500/10 px-2 py-0.5 text-[10.5px] font-medium text-amber-700">
                      <CircleAlert className="size-3" /> 主力降级中
                    </span>
                  )}
                </div>
                <div className="mt-0.5 text-[11.5px] text-muted-foreground">
                  30d <span className="tnum mono">{r.tokens30d.toLocaleString()} 万 tokens</span> · 占比 <span className="tnum mono">{r.share}%</span>
                </div>
              </div>
              {/* 预算熔断 */}
              <div className="ml-auto flex min-w-[180px] items-center gap-2">
                <Flame className={cn('size-3.5', r.used > 70 ? 'text-amber-600' : 'text-muted-foreground')} />
                <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-stone-100">
                  <div className={cn('h-full rounded-full', r.used > 70 ? 'bg-amber-500' : 'bg-sky-700')} style={{ width: `${(r.used / r.budget) * 100}%` }} />
                </div>
                <span className="tnum mono text-[11px] text-muted-foreground">{r.used}/{r.budget}%</span>
              </div>
            </div>

            {/* 降级链 */}
            <div className="mt-4 flex flex-wrap items-stretch gap-2">
              {r.channels.map((c, i) => {
                const st = CH_STATE[c.state];
                return (
                  <div key={c.name} className="flex items-center gap-2">
                    <div className={cn('min-w-[168px] rounded-md border p-2.5', st.cls)}>
                      <div className="flex items-center justify-between gap-2">
                        <span className="flex items-center gap-1.5 text-[12px] font-medium">
                          <span className={cn('size-[6px] rounded-full', st.dot, c.state === 'degraded' && 'pulse-dot')} />
                          {c.name}
                        </span>
                        <span className={cn('rounded px-1 py-0.5 text-[10px] font-semibold', KIND_STYLE[c.kind])}>{c.kind}</span>
                      </div>
                      <div className="mt-1 flex items-center justify-between text-[10.5px] text-muted-foreground">
                        <span>{st.label}</span>
                        <span className="tnum mono">P95 {c.p95}ms</span>
                      </div>
                    </div>
                    {i < r.channels.length - 1 && <ArrowDown className="size-3.5 rotate-[-90deg] text-muted-foreground" />}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      <p className="text-[11px] text-muted-foreground">
        分级路由：按失败率自动沿「主力 → 备用 → 兜底」降级链切换；预算熔断按价格簿零价快照 + 内部成本参考口径计算。
      </p>
    </div>
  );
}
